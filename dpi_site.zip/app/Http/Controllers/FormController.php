<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Domain;
use App\Models\Contact;
use App\Models\Country;
use App\Models\Service;
use App\Mail\NotifyMail;
use App\Mail\ContactMail;
use App\Models\Newsletter;
use App\Models\Testimonial;
use App\Mail\NewsletterMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class FormController extends Controller
{
   

    public function register(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|unique:users|max:255',
        ]);
        
        if ($validator->fails()) {
            return redirect()
                    ->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('erreur_registration','Error during registration.'); 
        }
 
        $emp = new User;
 
        $emp->name = $request->name;
        $emp->email = $request->email;
        $emp->password = $request->password;
        $emp->config_level = "first";
        $emp->id_user_type =1;
 
        if($emp->save()){
            Mail::to($emp->email)->send(new NotifyMail($emp->email,$emp->name));
            //Mail::to($emp->email)->send(new WelcomeMember($emp, $options));
            return redirect('mail-confirm')->with('status','Thanks for signing up, we value your business.')
            ->with('email',$emp->email)
            ->with('name',$emp->name);
        }else{
            return redirect()->with('erreur','Error during registration.'); 
        };
 
       
 
    }

    public function mail_confirm(Request $request)
    {
        return view("register.mail_confirm");
 
    }
    public function mail_confirmation(Request $request)
    {
        return view("register.mail_confirmation");
 
    }
    public function resgister_start_configuration(Request $request)
    {
        $countries = Country::All();
        $domains = Domain::All();
        return view("register.register_strat_configuration")->with(compact('countries','domains'));

    }

    public function dashboard(Request $request)
    {
        $countries = Country::All();
        $domains = Domain::All();
        return view("user.dashboard")->with(compact('countries','domains'));

    }


    public function savetestimonial(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required|max:100',
            'last_name' => 'required',
            'domain' => 'required',
            'testimonial' => 'required',
            'photo' => 'required|image', //|mimes:jpg,png,jpeg,gif,svg|max:2048
        ]);


        $imageName = time().'.'.$request->photo->extension();  
       
        $request->photo->move('images/testimonial', $imageName);

        $path = base_path().'/images/testimonial/';
        $testimonial = new Testimonial;
 
        $testimonial->first_name = $request->first_name;
        $testimonial->last_name = $request->last_name;
        $testimonial->domain = $request->domain;    
        $testimonial->testimonial = $request->testimonial;
        $testimonial->photo = "/images/testimonial/".$imageName;
        $testimonial->statut = "no";

        if($testimonial->save()){
            //Mail::to($testimonial->email)->send(new ContactMail($testimonial->first_name));
            return view('confirm_testimonial')->with("success_testimonial","Message sent successfully")
                                     ->with('name',$testimonial->first_name);;
        }else{
            return redirect()->back()->with("erreur_testimonial","Error during saving");
        }

    }

    public function savecontact(Request $request)
    {
        $validated = $request->validate([
            'full_name' => 'required|max:100',
            'email' => 'required|email',
            'subject' => 'required',
            'message' => 'required',
        ]);

        $contact = new Contact;
 
        $contact->full_name = $request->full_name;
        $contact->email = $request->email;
        $contact->subject = $request->subject;
        $contact->message = $request->message;

        if($contact->save()){
            Mail::to($contact->email)->send(new ContactMail($contact->full_name));
            return redirect()->back()->with("succes","Message sent successfully")
                                     ->with('name',$contact->full_name);
        }else{
            return redirect()->back()->with("erreur","Error during saving");
        }

    }
    public function subscibeNewsletter(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email',
        ]);

        $newsletter = new Newsletter;
 
        $newsletter->email = $request->email;

        if($newsletter->save()){

            Mail::to($request->email)->send(new NewsletterMail($newsletter->email));
            return redirect()->back()->with("success","Message sent successfully");
                                     
        }else{

            return redirect()->back()->with("erreur","Error during saving");
        }

    }
    public function service_ch(Request $request,int $id_service)

    {
        //$request->session()->forget('service_id');
        
        $request->session()->put('service_id', [$id_service]);
        $service =  Service::where('id_service', $id_service)->first();
        return view('pages.service_select_form')->with(compact('service'));

    }

    
}
