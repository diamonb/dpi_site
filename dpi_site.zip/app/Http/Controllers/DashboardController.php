<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\Domain;
use App\Models\Survey;
use App\Models\Contact;
use App\Models\Insight;
use App\Models\Service;
use App\Models\Newsletter;
use App\Models\Testimonial;
use App\Models\TypeService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class DashboardController extends Controller
{

    public function accueil()
    {
        return view("admin.accueil");
    }
    public function terms(Request $request)
    {
        /*$countries = Country::All();*/
        $page = Page::where('name', 'terms')->first();
        //$page = Page::where('id_page',1);
        return view("admin.update_terms")->with(compact('page'));

    }

    public function editTerms(Request $request)
    {
        if ($request->isMethod('post')) {

            $page =Page::where('id_page', $request->id_page)->first();
            $page->description = $request->description;
            if($page->update()){
                return redirect()->back()->with("succes","Updated successfuly");
            }else{
                return redirect()->back()->with("erreur","Error");
            }
        }         

    }

    public function privacyPolicy(Request $request)
    {
        /*$countries = Country::All();*/
        $page = Page::where('name', 'privacy_policy')->first();
        //$page = Page::where('id_page',1);
        return view("admin.update_privacy_policy")->with(compact('page'));

    }
    public function editPrivacyPolicy(Request $request)
    {
        if ($request->isMethod('post')) {

            $page =Page::where('id_page', $request->id_page)->first();
            $page->description = $request->description;
            if($page->update()){
                return redirect()->back()->with("succes","Updated successfuly");
            }else{
                return redirect()->back()->with("erreur","Error");
            }
        }
       
        

    }

    public function shippingPolicy(Request $request)
    {
        /*$countries = Country::All();*/
        $page = Page::where('name', 'shipping_policy')->first();
        //$page = Page::where('id_page',1);
        return view("admin.update_shipping_policy")->with(compact('page'));

    }
    public function editShippingPolicy(Request $request)
    {
        if ($request->isMethod('post')) {

            $page =Page::where('id_page', $request->id_page)->first();
            $page->description = $request->description;
            if($page->update()){
                return redirect()->back()->with("succes","Updated successfuly");
            }else{
                return redirect()->back()->with("erreur","Error");
            }
        }
       
        

    }

    public function rRPolicy(Request $request)
    {

        $page = Page::where('name', 'r_r_policy')->first();
        return view("admin.update_r_r_policy")->with(compact('page'));

    }
    public function editRRPolicy(Request $request)
    {
        if ($request->isMethod('post')) {

            $page =Page::where('id_page', $request->id_page)->first();
            $page->description = $request->description;
            if($page->update()){
                return redirect()->back()->with("succes","Updated successfuly");
            }else{
                return redirect()->back()->with("erreur","Error");
            }
        }
       
        

    }

    public function listContact(Request $request)
    {

        $contacts = Contact::All();
        return view("admin.list_contact")->with(compact('contacts'));

    }
    public function listNewsletter(Request $request)
    {

        $newsletters = Newsletter::All();
        return view("admin.list_newsletter")->with(compact('newsletters'));

    }
    public function listTestimonial(Request $request)
    {

        $testimonials = Testimonial::where('statut','no')->get();
        return view("admin.list_testimonial")->with(compact('testimonials'));

    }

    public function shareTestimonial(Request $request)
    {

        if ($request->isMethod('post')) {

            $testimonial =Testimonial::where('id_testimonial', $request->id_testimonial)->first();
            
            $testimonial->statut = "active";
            if($testimonial->update()){
                return redirect()->back()->with("success","Updated successfuly");
            }else{
                return redirect()->back()->with("erreur","Error");
            }
        }      

    }


    public function addSurvey()
    {

        return view("admin.add_survey");

    }
    public function addInsight()
    {

        return view("admin.add_insight");

    }
    public function storeSurvey(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), [
                'title' => 'required|max:255',
                'description' => 'required',
                'link'=>'required',
                'image' => 'required|image',
            ]);
            
            if ($validator->fails()) {
                return redirect()
                        ->back()
                        ->withErrors($validator)
                        ->withInput()
                        ->with('erreur_saving','Error during saving.'); 
            }
     
            $imageName = time().'.'.$request->image->extension();  
       
            $request->image->move('images/survey', $imageName);

            $survey = new Survey;
     
            $survey->title = $request->title;
            $survey->description = $request->description;
            $survey->image = "/images/survey/".$imageName;
            $survey->link = $request->link;
            $survey->statut = "no";

            if($survey->save()){
                return redirect()->back()->with("succes","Survey saved");
            }else{
                return redirect()->back()->with("erreur","Error during saving");
            }
        }
       
        

    }
    public function storeInsight(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), [
                'title' => 'required|max:255',
                'description' => 'required',
                'file'=>'required|file'
            ]);
            
            if ($validator->fails()) {
                return redirect()
                        ->back()
                        ->withErrors($validator)
                        ->withInput()
                        ->with('erreur_saving','Error during saving.'); 
            }
     
            $fileName = time().'.'.$request->file->extension();  
       
            $request->file->move('files/insight', $fileName);

            $insight = new Insight;
     
            $insight->title = $request->title;
            $insight->description = $request->description;
            $insight->file = "/files/insight/".$fileName;
            $insight->statut = "no";

            if($insight->save()){
                return redirect()->back()->with("succes","Insight saved");
            }else{
                return redirect()->back()->with("erreur","Error during saving");
            }
        }
       
        

    }
    public function listSurvey()
    {

        $surveys = Survey::All();
        return view("admin.list_survey")->with(compact('surveys'));

    }
    public function listInsight()
    {

        $insights = Insight::All();
        return view("admin.list_insight")->with(compact('insights'));

    }

    public function addService()
    {
        $typeservices = TypeService::All();

        return view("admin.add_service")->with(compact('typeservices'));

    }

    public function storeService(Request $request)
    {
        if ($request->isMethod('post')) {

            $validator = Validator::make($request->all(), [
                'libelle' => 'required|max:255',
                'description' => 'required',
                'application_fee' => 'required',
            ]);
            
            if ($validator->fails()) {
                return redirect()
                        ->back()
                        ->withErrors($validator)
                        ->withInput()
                        ->with('erreur_saving','Error during saving.'); 
            }
     

            $service = new Service;
     
            $service->libelle = $request->libelle;
            $service->description = $request->description;
            $service->application_fee = $request->application_fee;
            $service->service_price = $request->service_price;
            $service->id_type_service = $request->typeservice;
            $service->statut = "no";

            if($service->save()){
                return redirect()->back()->with("succes","Service saved");
            }else{
                return redirect()->back()->with("erreur","Error during saving");
            }
        }
       
        

    }
    public function listService()
    {

        $services = Service::All();
        return view("admin.list_service")->with(compact('services'));

    }
    
    
    
       
}
