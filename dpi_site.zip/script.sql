INSERT INTO type_services (id_type_service, libelle, created_at, updated_at) VALUES (NULL, 'marketing', NULL, NULL), 
(NULL, 'finance', NULL, NULL), 
(NULL, 'digital', NULL, NULL);