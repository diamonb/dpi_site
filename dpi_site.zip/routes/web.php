<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormController;
use App\Http\Controllers\SurveyController;
use App\Http\Controllers\AccueilController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DashboardUserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [AccueilController::class,'accueil'])->name('accueil');

Route::get('invest_with_us', [AccueilController::class,'investwithus'])->name('investwithus');
Route::get('partner', [AccueilController::class,'partner'])->name('partner');
Route::get('consultant', [AccueilController::class,'consultant'])->name('consultant');
Route::get('founder', [AccueilController::class,'founder'])->name('founder');
Route::get('career', [AccueilController::class,'career'])->name('career');
Route::get('sponsor', [AccueilController::class,'sponsor'])->name('sponsor');
Route::get('do_business', [AccueilController::class,'doBusiness'])->name('dobusiness');


Route::get('marketing', [AccueilController::class,'marketing'])->name('marketing');
Route::get('finance', [AccueilController::class,'finance'])->name('finance');
Route::get('digital', [AccueilController::class,'digital'])->name('digital');

Route::post('service_ch/{id_service}',[FormController::class,'service_ch'])->name('service_choose');

Route::get('contact', [AccueilController::class,'contact'])->name('contact');
Route::post('contact', [FormController::class,'savecontact'])->name('savecontact');

Route::get('/compagny', [AccueilController::class,'compagny'])->name('compagny');
Route::get('/#service', [AccueilController::class,'service'])->name('service');
Route::get('/#dpi', [AccueilController::class,'accueil'])->name('accueildpi');
Route::get('/#marketing', [AccueilController::class,'accueil'])->name('accueilmarketing');
Route::get('/#finance', [AccueilController::class,'accueil'])->name('accueilfinance');
Route::get('/#digital', [AccueilController::class,'accueil'])->name('accueildigital');
Route::get('/#about', [AccueilController::class,'accueil'])->name('accueilabout'); 
Route::get('/#reference', [AccueilController::class,'accueil'])->name('accueilreference');

Route::post('subscribe_newsletter', [FormController::class, 'subscibeNewsletter'])->name('subscibe_newsletter');

// terms

Route::get('/privacy', [AccueilController::class,'privacy'])->name('privacypolicy');
Route::get('/return', [AccueilController::class,'return'])->name('returnpolicy');
Route::get('/shipping', [AccueilController::class,'shipping'])->name('shippingpolicy');
Route::get('/terms', [AccueilController::class,'terms'])->name('termspolicy');

Route::get('testimonial', [AccueilController::class,'testimonial'])->name('testimonial');
Route::post('testimonial', [FormController::class,'savetestimonial'])->name('testimonial');

//
Route::post('register-form', [FormController::class, 'register'])->name('register_form');

//
Route::get('/about', [AccueilController::class,'about'])->name('about');
Route::get('/about#vmvo', [AccueilController::class,'about'])->name('about_vmvo');
Route::get('/about#company', [AccueilController::class,'about'])->name('about_company');
Route::get('/about#leadership', [AccueilController::class,'about'])->name('about_leadership');
Route::get('/about#when_call', [AccueilController::class,'about'])->name('about_when_call');

//
Route::get('/avis', [AccueilController::class,'avis'])->name('avis');
Route::get('/dielshop', [ShopController::class,'accueil'])->name('dielshop');
Route::get('/dielsurvey', [SurveyController::class,'accueil'])->name('dielsurvey');

//User dashboard
Route::get('/user_dashboard', [DashboardUserController::class,'accueil'])->name('dashboardUser');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

/*
// dashboard admin
Route::get('dashboard/add_survey', [DashboardController::class,'addSurvey'])->name('add_survey');
Route::post('dashboard/store_survey', [DashboardController::class,'storeSurvey'])->name('store_survey');
Route::get('dashboard/list_survey', [DashboardController::class,'listSurvey'])->name('list_survey'); 

Route::get('dashboard/add_insight', [DashboardController::class,'addInsight'])->name('add_insight');
Route::post('dashboard/store_insight', [DashboardController::class,'storeInsight'])->name('store_insight');
Route::get('dashboard/list_insight', [DashboardController::class,'listInsight'])->name('list_insight'); 

Route::get('dashboard/add_service', [DashboardController::class,'addService'])->name('add_service');
Route::post('dashboard/store_service', [DashboardController::class,'storeService'])->name('store_service');
Route::get('dashboard/list_service', [DashboardController::class,'listService'])->name('list_service'); 

Route::get('dashboard/add_type_service', [DashboardController::class,'addTypeService'])->name('add_type_service');



Route::get('dashboard/update_terms', [DashboardController::class,'terms'])->name('update_terms');
Route::post('dashboard/edit_terms', [DashboardController::class,'editTerms'])->name('EditTerms');

Route::get('dashboard/update_privacy_policy', [DashboardController::class,'privacyPolicy'])->name('update_privacy_policy');
Route::post('dashboard/edit_privacy_policy', [DashboardController::class,'editPrivacyPolicy'])->name('edit_privacy_policy');

Route::get('dashboard/update_shipping_policy', [DashboardController::class,'shippingPolicy'])->name('update_shipping_policy');
Route::post('dashboard/edit_shipping_policy', [DashboardController::class,'editShippingPolicy'])->name('edit_shipping_policy');

Route::get('dashboard/update_r_r_policy', [DashboardController::class,'rRPolicy'])->name('update_r_r_policy');
Route::post('dashboard/edit_r_r_policy', [DashboardController::class,'editRRPolicy'])->name('edit_r_r_policy');

Route::get('dashboard', [DashboardController::class,'accueil'])->name('dashboard_admin_accueil');

Route::get('dashboard/list_contact', [DashboardController::class,'listContact'])->name('list_contact');
Route::get('dashboard/list_newsletter', [DashboardController::class,'listNewsletter'])->name('list_newsletter');
Route::get('dashboard/list_testimonial', [DashboardController::class,'listTestimonial'])->name('list_testimonial');
Route::post('dashboard/share_testimonial', [DashboardController::class,'shareTestimonial'])->name('share_testimonial');
*/
require __DIR__.'/auth.php';
