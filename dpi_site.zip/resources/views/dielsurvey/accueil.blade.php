@extends("template.masterother")
@section("content")
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">DIELSurvey</p>
    
  </div>
  <div class="container">
    <div class="row mt-4 mb-4">
          <div class="col">
          </div>
          <div class="col">
            <div class="input-group">
            <div class="form-outline">
              <input type="search" id="form1" class="form-control" />
              <label class="form-label" for="form1">Search a DIELSurvey here</label>
            </div>
            <button type="button" class="btn btn-primary">
              <i class="fas fa-search"></i>
            </button>
            </div>
          </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <div class="entete_column">
              <p class="text-center h3">Insights</p>
        </div>
        @foreach($insights as $insight)
        <div class="row">
          <div class="col-md-10">
            <p><b>{{$insight->title}}</b></p>
            <p><small>{!!$insight->description!!}</small></p>
          </div>
          <div class="col-md-2">
            <a class="" href="{{asset($insight->file)}}" download><i data-mdb-toggle="tooltip" title="Download insight" class="justify-content-end fas fa-download"></i></a>
          </div>
        </div>         
          <hr>
        @endforeach
      </div>
      <div class="col-md-6">
        <div class="entete_column">
              <p class="text-center h3">Surveys</p>
        </div>
        @foreach($surveys as $survey)
        <div class="row">
          <div class="col-md-4">
          <img class="" src="{{asset($survey->image)}}" alt="" width="100%">
          </div>
          <div class="col-md-8">
              <p><b>{{$survey->title}}</b> </p>
              <p>{!!$survey->description!!}</p>
              <p class="text-end"><i data-mdb-toggle="tooltip" title="Share" class="fas fa-share fa-2x text-success"></i> 
              <button shout-button
              class="btn btn-outline-primary"
              data-sh-form="{{$survey->link}}"
              data-sh-close-on-complete="false"
              data-sh-type="slideout"
              data-sh-direction="right"
              sh-initial-color="#2A98C6"> Take this DIELSurvey</button>
            </p>
          </div>
        </div>
        <hr>
        @endforeach
        {!! $surveys->links() !!}
      </div>
      <div class="col-md-3">
        <div class="entete_column">
              <p class="text-center h3">News</p>
        </div>
        <div class="row">
          <div class="col">
          <img class="" src="{{asset('images/news.jpg')}}" alt="" width="100%">
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
  <button class="btn btn-primary d-flex p-2" type="button"><i class="material-icons pmd-sm">Become participant</i></button>
<footer>
    @include('partials/foot')
</footer>
@endsection