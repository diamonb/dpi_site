@extends("template.masterother")
@section("content")
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Terms of Use</p>
    
  </div>
<div class="container mt-5">
    <p class="h4 mb-2 mt-5">Terms and Conditions</p>
    {!!$page->description!!}
</div>

<footer>
    @include('partials/foot')
</footer>
@endsection