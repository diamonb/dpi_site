@extends("template.masterother")
@section("content")
  <div class="banniere_contact">
        <p class="h1 text-center pt-5">DPI Fin. & Services</p>
  </div>

  <div class="">
        <p class="h1 text-center mt-4">OUR DPI Finance services</p>
  </div>

  <div class="container mb-5 finance_class" id="finance">
    <div class="row">
          @foreach($services as $service)

          <div class="col-lg-3">
              <div class="accordion" id="accordionExample">
                  <div class="accordion-item">
                      <h2 class="accordion-header" id="headingOne">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                      <strong>{{$service->libelle}}</strong>
                      </button>
                      </h2>
                      <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                          {!!$service->description!!}
                          <p>
                              <form action="" method ="POST">
                                  <input type="hidden" value="{{$service->id_service}}" name="service">
                                  <button class="btn btn-success">Add to card</button> &nbsp; &nbsp; <button class="btn btn-primary">Take</button>
                              </form>
                          </p>
                      </div>
                      </div>
                  </div>
              </div>
          </div>
          @endforeach

      </div>
</div>

<footer>
    @include('partials/foot')
</footer>
@endsection