@extends("template.masterother")
@section("content")




<div class="row ">

    <!--Grid column-->
    <div class="col-md-6">
        <img src="{{asset('images/partner.jpg')}}" width="100%" alt="">
    </div>

    <div class="col-md-6">
    <h2 class="text-center w-responsive mx-auto h1">Join our great family!</h2>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        @if ($message = Session::get('succes'))

        <div class="alert alert-success ">

            <button type="button" class="close" data-dismiss="alert">×</button>

            <strong>{{ $message }}</strong>

        </div>

        @endif
        @error('name')
        <span class="text-danger">{{$message}}</span>
        @enderror

        <form id="contact-form" name="contact-form" action="{{route('savecontact')}}" method="POST">
        {{csrf_field()}}
            <div class="form-group">
                <label for="company"><strong>Highest level of education you have completed</strong></label>
                <input type="text" class="form-control" id="company" placeholder="">
            </div>
            <div class="form-group">
                <label for="company"><strong>Field *</strong></label>
                <input type="text" class="form-control" id="company" placeholder="">
            </div>
            <br>
            <div class="form-group">
                <label for=""><strong>Background experience *</strong></label>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="duration">
                                - 3 years
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="duration">
                                3 - 5 years
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="duration">
                                5 - 10 years
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="duration">
                                10 - 15 years
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="duration">
                                15 years +
                            </label>
                        </div>
                    </div>

                </div>
            </div>
            <br>

            <div class="form-group">
                <label for="experience">Tell us about your experience and motivations *</label>
                <textarea class="form-control" id="experience" ></textarea>
            </div>
            <br>
            <div class="form-group">
                <label for=""><strong>Preferred language *</strong></label>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            English
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Spanish
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            French
                            </label>
                        </div>
                    </div>
                </div>   
            </div>
            <br>

            <div class="form-group">
                <label for=""><strong>How did you hear about us *</strong></label>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Facebook/WhatsApp
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Linkedin
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Website
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Current employee
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Previous employee
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Friend (word of mouth)
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Walk in
                            </label>
                        </div>
                    </div>
                </div>
                
            </div>
            <fieldset class="scheduler-border">
                <legend class="scheduler-border">Candidate details</legend>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="first_name"><strong>First name *</strong></label>
                                <input type="text" class="form-control" id="first_name" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="last_name"><strong>Last name *</strong></label>
                                <input type="text" class="form-control" id="last_name" placeholder="">
                            </div>
                   
                        </div>
                    </div>
                    <div class="row">
                            <div class="form-group">
                                <label for="email"><strong>Email *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Number *</strong></label>
                                <input type="number" class="form-control" id="emnumberail" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Address *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Address 2</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>City/town *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>State / Province *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label class="" for="country"><strong>Country</strong></label>
                                <select class="form-select" id="country">
                                    @foreach($countries as $country)
                                    <option value="{{$country->id}}">{{$country->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group mt-2">
                                <label for="email"><strong>Zip/Postal code</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>

                    </div>
            </fieldset>
            <div class="row">
                <div class="form-group mt-2">
                    <label for="linkedin"><strong>Linkedin </strong></label>
                    <input type="text" class="form-control" id="linkedin" placeholder="">
                </div>
            </div>
            <div class="form-group mt-2">
                        <label for="linkedin"><strong>Resume </strong></label>
                        <input type="file" name="image" class="form-control" id="image">
            </div>
            <div class="text-center text-md-left">
                <a class="btn btn-primary" >Send</a>
            </div>

        </form>
        <br>

        <div class="status"></div>
    </div>

</div>

<footer>
    @include('partials/foot')
</footer>
@endsection