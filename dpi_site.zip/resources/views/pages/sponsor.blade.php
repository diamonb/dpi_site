@extends("template.masterother")
@section("content")




<div class="row ">

    <!--Grid column-->
    <div class="col-md-6">
        <img src="{{asset('images/consultant.jpg')}}" width="100%" alt="">
    </div>

    <div class="col-md-6">
    <h2 class="text-center w-responsive mx-auto h1">Join and support us!</h2>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        @if ($message = Session::get('succes'))

        <div class="alert alert-success ">

            <button type="button" class="close" data-dismiss="alert">×</button>

            <strong>{{ $message }}</strong>

        </div>

        @endif
        @error('name')
        <span class="text-danger">{{$message}}</span>
        @enderror

        <form id="contact-form" name="contact-form" action="{{route('savecontact')}}" method="POST">
        {{csrf_field()}}
            <div class="form-group">
                    <label for=""><strong>Type of Support *</strong></label>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                    Donation
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                    Sponsorship
                                </label>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="form-group">
              <label for="amount"><strong>Amount/Value of Support ($) *</strong></label>
              <input type="number" class="form-control" id="amount" placeholder="">
            </div>
            <div class="form-group">
              <label for="motivation"><strong>Purpose and Motivation </strong></label>
              <label for=""><small>Please briefly explain why you are interested in sponsoring/donating</small></label>
              <textarea class="form-control" id="motivation" placeholder=""></textarea>
            </div>
            <div class="form-group">
                    <label for=""><strong>Recognition and Visibility *</strong></label>
                    <label for=""><small>Are you seeking any form of recognition for your sponsorship or donation?</small></label>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                Yes
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                No
                                </label>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="form-group">
                    <label for=""><strong>If yes </strong></label>
                    <label for=""><small>What type of recognition would you prefer? </small></label>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                Logo placement
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                Acknowledgement in publications
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                Social media mentions
                                </label>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="form-group">
              <label for="customized"><strong>Are you open to discussing customized recognition opportunities based on the project? *</strong></label>
              <input type="text" class="form-control" id="customized" placeholder="">
            </div>
            <div class="form-group">
                    <label for=""><strong>Duration of Support *</strong></label>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                One-time
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                Ongoing
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                                <label class="form-check-label" for="duration">
                                Specific Duration
                                </label>
                            </div>
                        </div>
                    </div>
            </div>

            <fieldset class="scheduler-border">
                <legend class="scheduler-border">Sponsor Details</legend>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="first_name"><strong>First name</strong></label>
                                <input type="text" class="form-control" id="first_name" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="last_name"><strong>Last name</strong></label>
                                <input type="text" class="form-control" id="last_name" placeholder="">
                            </div>
                   
                        </div>
                    </div>
                    <div class="row">
                            <div class="form-group">
                                <label for="email"><strong>Email *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Number *</strong></label>
                                <input type="number" class="form-control" id="emnumberail" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Zip/Postal code</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Address *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>Address 2</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>City/town *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="email"><strong>State / Province *</strong></label>
                                <input type="email" class="form-control" id="email" placeholder="">
                            </div>
                            <div class="form-group">
                                <label class="" for="country"><strong>Country</strong></label>
                                <select class="form-select" id="country">
                                    @foreach($countries as $country)
                                    <option value="{{$country->id}}">{{$country->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                    </div>
            </fieldset>
            <br>
            <div class="form-group">
                <label for=""><strong>How did you hear about us *</strong></label>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Facebook/WhatsApp
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Linkedin
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Website
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Current Sponsor
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Previous Sponsor
                            </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Friend (word of mouth)
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="duration" id="duration" value="duration" checked>
                            <label class="form-check-label" for="">
                            Walk in
                            </label>
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="text-center text-md-left">
                <a class="btn btn-primary" >Send</a>
            </div>

        </form>
        <br>

        <div class="status"></div>
    </div>

</div>

<footer>
    @include('partials/foot')
</footer>
@endsection