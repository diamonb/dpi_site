@extends("template.masterother")
@section("content")
  <div class="banniere_contact">
        <p class="h1 text-center pt-5">Contact us</p>
  </div>

  <div class="container">
    <div class="row">
        <div class="col-lg-10">
            <!--Section: Contact v.2-->
<section class="mb-4 mt-4">

<!--Section description-->
<h2 class="text-center w-responsive mx-auto mb-5">Feel free to contact our committed team to assist with your need now.</h2>

<div class="row justify_context_center">

    <!--Grid column-->
    <div class="col-md-2">

    </div>

    <div class="col-md-8 mb-md-0 mb-5">
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        @if ($message = Session::get('succes'))

        <div class="alert alert-success ">

            <button type="button" class="close" data-dismiss="alert">×</button>

            <strong>{{ $message }}</strong>

        </div>

        @endif
        @error('name')
        <span class="text-danger">{{$message}}</span>
        @enderror

        <form id="contact-form" name="contact-form" action="{{route('savecontact')}}" method="POST">
        {{csrf_field()}}
            <!--Grid row-->
            <div class="row">

                <!--Grid column-->
                <div class="col-md-6">
                    <div class="md-form mb-0">
                        <label for="name" class="">Full name</label>
                        <input type="text" id="name" name="full_name" class="form-control @error('title') is-invalid @enderror">
                        @error('required')
                            <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6">
                    <div class="md-form mb-0">
                        <label for="email" class="">Email</label>
                        <input type="text" id="email" name="email" class="form-control">
                        
                    </div>
                </div>
                <!--Grid column-->

            </div>
            <!--Grid row-->

            <!--Grid row-->
            <div class="row">
                <div class="col-md-12">
                    <div class="md-form mb-0">
                        <label for="subject" class="">Subject</label>
                        <input type="text" id="subject" name="subject" class="form-control">
                    </div>
                </div>
            </div>
            <!--Grid row-->

            <!--Grid row-->
            <div class="row">

                <!--Grid column-->
                <div class="col-md-12">

                    <div class="md-form">
                    <label for="message">Message</label>
                        <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                        
                    </div>

                </div>
            </div>
            <!--Grid row-->

        </form>
        <br>
        <div class="text-center text-md-left">
            <a class="btn btn-primary" onclick="document.getElementById('contact-form').submit();">Send</a>
        </div>
        <div class="status"></div>
    </div>
    <div class="col-md-2">

</div>
    <!--Grid column-->
</div>
<div class="row mt-5">
            <div class="col-md-2">

            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col">
                    <i class="fas fa-map-marker-alt fa-2x text-warning"></i> <br>
                        <span> Houston,Texas (US)</span><br>
                        <span>Libreville, Gabon</span>
                    </div>

                    <div class="col text-center">
                        <i class="fas fa-phone fa-2x text-warning"></i> <br>
                            <span>+1 713-292-4421</span>
                    </div>

                    <div class="col text-end">
                        <p class="text-end"><i class="fas fa-envelope fa-2x text-end text-warning"></i></p>
                        
                            <span>contact@dielpi.com </span> <br>
                    </div>
                </div>
            </div>
            <div class="col-md-2">

            </div>
            

</div>

</section>
<!--Section: Contact v.2-->
        </div>
        <div class="col-lg-2">

        </div>
    </div>
 
  </div>


<footer>
    @include('partials/foot')
</footer>
@endsection