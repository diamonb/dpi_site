@extends("template.masterother")
@section("content")
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Shipping Policy  </p>
    
  </div>

  <div class="container mt-5">
  {!!$page->description!!}
    
  </div>

<footer>
    @include('partials/foot')
</footer>
@endsection