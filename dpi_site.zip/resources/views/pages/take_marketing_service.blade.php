@extends("template.masterother")
@section("content")
  <div class="banniere_contact">
        <p class="h1 text-center pt-5">DPI Marketing & Services</p>
  </div>

  <div class="">
        <p class="h1 text-center mt-4">OUR DPI Marketing services</p>
  </div>


</div>


<footer>
    @include('partials/foot')
</footer>
@endsection