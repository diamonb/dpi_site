@extends("template.dashboard")
@section("content")
    <div class="row">
        <div class="col-lg-12">
            <h2 class="m-lg-4">List of services</i></h2>

        </div>

    </div>
    <div class="row">
            <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">Service</th>
                <th scope="col">Service description</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($services as $service)
                <tr>
                    <td>{{$service->libelle}}</td>
                    <td>{!!$service->description!!}</td>
                    <td><button class="btn btn-danger">Delete</button>&nbsp;&nbsp;<button class="btn btn-success">Update</button></td>
                </tr>
                @endforeach
            </tbody>
            </table>

    </div>
@endsection