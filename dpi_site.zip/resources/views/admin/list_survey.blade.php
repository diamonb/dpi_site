@extends("template.dashboard")
@section("content")
    <div class="row">
        <div class="col-lg-12">
            <h2 class="m-lg-4">List of surveys</i></h2>

        </div>

    </div>
    <div class="row">
            <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">Survey title</th>
                <th scope="col">Survey description</th>
                <th scope="col">Survey link</th>
                <th scope="col">Survey image</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($surveys as $survey)
                <tr>
                    <td>{{$survey->title}}</td>
                    <td>{!!$survey->description!!}</td>
                    <td>{{$survey->link}}</td>
                    <td><img src="{{asset($survey->image)}}" alt="photo" class="img img-thumbnail"></td>
                    <td><button class="btn btn-danger">Delete</button>&nbsp;&nbsp;<button class="btn btn-success">Update</button></td>
                </tr>
                @endforeach
            </tbody>
            </table>

    </div>
@endsection