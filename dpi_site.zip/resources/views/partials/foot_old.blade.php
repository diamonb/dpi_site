<div class="">
<div class="container" id="reference">
  <h2>Our  Partners</h2>
   <section class="customer-logos slider">
      <div class="slide"><img src="{{asset('images/partenaires/fundwise.png')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/cannabiz.png')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/ophra.png')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/yield4.jpg')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/markis.png')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/kantar.jpg')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/nielsen.png')}}"></div>
      <div class="slide"><img src="{{asset('images/partenaires/ipsos.jpg')}}"></div>
     
   </section>
</div>
     
</div>
<div class="pied">
   <div class="container" style="color: white" id="about">
      <div class="row mt-4">
         <div class="col mt-4">
            <b>ADDRESS</b>
                <p><i class="fa fa-address-card"></i> DPI USA LLC Houston, TX 77064</p>
                <p><i class="fa fa-phone"></i> Tél : </p>
                <p><i class="fa fa-envelope-open"></i> Email : dpi@dielpi.com / investors@dielpi.com </p>
                <p>Follow us <span><a target="_blank" href="https://www.facebook.com/dpimarketingservices"><img src="{{asset('images/facebook.jpg')}}" alt="" height="50px"></a></span>&nbsp;<span><img src="{{asset('images/linkedin.png')}}" alt="" height="50px"></span></p>
         </div>

         <div class="col mt-4">
            <form id="contact">
               
                 <section class="fs-3">Let's stay in touch</section> 
               <section><b>Newsletter</b></section>
               <div class="form-group">
                   <label for="exampleFormControlInput1">name</label>
                   <input type="text" class="form-control" id="exampleFormControlInput1">
               </div>
               <div class="form-group">
                   <label for="exampleFormControlInput1">Email</label>
                   <input type="email" class="form-control" id="exampleFormControlInput1">
               <div class="form-group d-flex justify-content-center mt-2 ">
                  <button class="btn btn-primary float-right" >Submit</button>
               </div>

           </form>
         </div>
      </div>
   </div>

</div>