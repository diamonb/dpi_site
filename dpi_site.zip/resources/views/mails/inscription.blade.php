
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <!--[if (gte mso 9)|(IE)]>
    <xml>
        <o:OfficeDocumentSettings>
            <o:AllowPNG/>
            <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
    </xml>
    <![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- So that mobile will display zoomed in -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- enable media queries for windows phone 8 -->
    <meta name="format-detection" content="telephone=no"> <!-- disable auto telephone linking in iOS -->
    <meta name="format-detection" content="date=no"> <!-- disable auto date linking in iOS -->
    <meta name="format-detection" content="address=no"> <!-- disable auto address linking in iOS -->
    <meta name="format-detection" content="email=no"> <!-- disable auto email linking in iOS -->
    <meta name="author" content="Dieldpi.com">
    <title>DPI-mail</title>

    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <style type="text/css">
        /*Basics*/
        .content{
            background-color: #bfbfbf;
            padding:5%;
        }
        .content2{
            margin-top:1%;
            margin-left:44%;
        }
        .mail_box{
        box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px;
        margin-left:30%;
        width:40%;   
        background-color:#fff;
        padding:3%;
        }
        .bouttonn{width:120px; height:15px; background-color:#fcc200 ; margin-left:40%; padding:2%}
        .bouttonn>a{ color:#fff}
        .social{margin-top: 5px; margin-left: 42%;}
        .social>a{margin-right: 10px;}
    </style>
    </head>
    <body>
        <div class="content"> 
            <div class="mail_box">
                <img src="https://dev.dielpi.com/images/logo.jpeg" height="100" alt="DPI Logo" loading="lazy"/>
                <hr>
                <h1>Hi <?=$name?> </h1>
                <h3>Thank you for joining our community.</h3>
                <h3>Please click the link below to confirm your email address and activate your DPI's account: </h3>  
                <div class="bouttonn"><a style="margin-left:5%; font-size:18px;" href=<?php echo "http://dev.dielpi.com/mail-confirmation?mail=".$email ?>>Verify Email</a></div>   
                <h5>If clicking on the above button does not work, please copy, and paste the URL below in a browser to verify your email address:</h5>
                <p><?php echo "http://dev.dielpi.com/mail-confirmation?mail=".$email ?></p>
            </div>
            <div class="content2">
                <a  target="_blank" href="https://www.facebook.com/dielpartnersinternational" ><img src="https://dev.dielpi.com/images/social/facebook.png" alt="" width="32px"></a>

                <a  target="_blank" href="https://www.facebook.com/dielpartnersinternational" role="button"><img src="https://dev.dielpi.com/images/social/whatsapp.png" alt="" width="32px"></a>

                <a target="_blank"  href="https://twitter.com/DPIUSALLC" role="button"><img src="https://dev.dielpi.com/images/social/twitter.png" alt="" width="32px"></a>

                <a target="_blank"  href="https://www.youtube.com/channel/UCe5bcTViOxKYTvZQdoo7oZw" role="button"><img src="https://dev.dielpi.com/images/social/youtube.png" alt="" width="32px"></a>

                <a  target="_blank" href="https://www.instagram.com/dpiusallc/" role="button"><img src="https://dev.dielpi.com/images/social/instagram.png" alt="" width="32px"></a>
        
                <a target="_blank"  href="https://www.linkedin.com/company/dpiusallc" role="button" ><img src="https://dev.dielpi.com/images/social/linkedin.png" alt="" width="32px"></a>     
            </div>
        </div>

            
    </body>
</html>
