
<?php $__env->startSection("content"); ?>
  <div class="banniere_contact">
        <p class="h1 text-center pt-5">DPI Fin. & Services</p>
  </div>

  <div class="">
        <p class="h1 text-center mt-4">OUR DPI Finance services</p>
  </div>

  <div class="container mb-5 finance_class" id="finance">
    <div class="row">
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-lg-3">
              <div class="accordion" id="accordionExample">
                  <div class="accordion-item">
                      <h2 class="accordion-header" id="headingOne">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                      <strong><?php echo e($service->libelle); ?></strong>
                      </button>
                      </h2>
                      <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                          <?php echo $service->description; ?>

                          <p>
                              <form action="" method ="POST">
                                  <input type="hidden" value="<?php echo e($service->id_service); ?>" name="service">
                                  <button class="btn btn-success">Add to card</button> &nbsp; &nbsp; <button class="btn btn-primary">Take</button>
                              </form>
                          </p>
                      </div>
                      </div>
                  </div>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
</div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/pages/finance.blade.php ENDPATH**/ ?>