
<?php $__env->startSection("content"); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-10">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
        <?php echo e(session('status')); ?>

        <?php endif; ?>
        </div>
        <div class="text-center mb-3">
            <h5>Welcome back !</h5>
            <p>Follow the step to configurate your dashbord</p>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-6 align-self-center">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        <span class="h3">Configuration</span>
        <form class="mt-5" name="register" id="register" method="post" action="<?php echo e(route('activate_dashboard')); ?>">
            <?php echo csrf_field(); ?>
                    <div class="form-outline mb-4">
                        <select class="form-select" id="domain" aria-label="Default select example">
                        <option selected>Open this select category</option>
                        <option value="">CLIENT</option>
                        <option value="">CONSULTANT</option>
                        <option value="">INVESTOR</option>
                        <option value="">PARTENER</option>
                        </select>
                        <label class="form-label" for="domain">Category*</label>
                    </div>

                    <div class="form-outline mb-4">
                        <select class="form-select" id="domain" aria-label="Default select example">
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->countrycode); ?>"><?php echo e($country->countryname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label class="form-label" for="domain">Country</label>
                    </div>

                    <div class="form-outline mb-4">
                        <input type="text" id="form6Example2" class="form-outline" />
                        <label class="form-label" for="form6Example2">State</label>
                    </div>
                    
                    <div class="form-outline mb-4">
                        <input type="text" id="form6Example1" class="form-outline" />
                        <label class="form-label" for="form6Example1">City</label>
                    </div>
                    <div class="form-outline mb-4">
                        <input type="text" id="form6Example2" class="form-outline" />
                        <label class="form-label" for="form6Example2">Address</label>
                    </div>
                    <div class="form-outline mb-4">
                        <input type="number" id="form6Example6" class="form-outline" />
                        <label class="form-label" for="form6Example6">Phone</label>
                    </div>

                    
                    <div class="form-outline mb-4">
                        <select class="form-select" id="domain" aria-label="Default select example">
                        <option selected>Open this to select domain</option>
                        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($domain->id_domain); ?>"><?php echo e($domain->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label class="form-label" for="domain">Primary need*</label>
                    </div>
                    <!-- Message input -->
                    <div class="form-outline mb-4">
                        <textarea class="form-outline" id="form6Example7" rows="4"></textarea>
                        <label class="form-label" for="form6Example7">Tell us about your project</label>
                    </div>

                    <div class=" mb-4">
                        <input type="file" class="form-control" id="customFile" />
                        <label class="" for="customFile">Tell us about your project - Add file</label>                      
                    </div>
                    <div class="form-outline mb-4">
                        <input type="text" id="website" class="form-outline" />
                        <label class="form-label" for="website">Website</label>
                    </div>


                <!-- Submit button -->
                <button type="submit" class="btn btn-primary btn-block mb-4">SUBMIT</button>
                </form>
            </div>
        </div>
    
        </div>
</div>
</div>

  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/register/register_strat_configuration.blade.php ENDPATH**/ ?>