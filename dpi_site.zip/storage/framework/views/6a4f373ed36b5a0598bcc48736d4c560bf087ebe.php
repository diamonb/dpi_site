
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">DIELSurvey</p>
    
  </div>
  <div class="container">
    <div class="row mt-4 mb-4">
          <div class="col">

          </div>
          <div class="col">
            <div class="input-group">
            <div class="form-outline">
              <input type="search" id="form1" class="form-control" />
              <label class="form-label" for="form1">Search a DIELSurvey here</label>
            </div>
            <button type="button" class="btn btn-primary">
              <i class="fas fa-search"></i>
            </button>
            </div>
          </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <div class="entete_column">
              <p class="text-center h3">Insights</p>
        </div>

      </div>
      <div class="col-md-6">
        <div class="entete_column">
              <p class="text-center h3">Surveys</p>
        </div>
        <?php for($i = 0; $i < 5; $i++): ?>
        <div class="row">
          <div class="col-md-4">
          <img class="" src="<?php echo e(asset('images/survey.jpg')); ?>" alt="" width="100%">
          </div>
          <div class="col-md-8">
              <p><b>Survey title</b> </p>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae ipsa dolore, 
                quo sint asperiores inventore laudantium amet eveniet at esse temporibus voluptate. 
                Ab deleniti beatae libero tempore sunt labore exercitationem.</p>
                <p class="text-end"><i data-mdb-toggle="tooltip" title="Share" class="fas fa-share fa-2x text-success"></i> <button type="button" class="btn btn-outline-primary ms-2">Take this DIELSurvey</button></p>
          </div>
        </div>
        <hr>
        <?php endfor; ?>

      </div>
      <div class="col-md-3">
        <div class="entete_column">
              <p class="text-center h3">News</p>
        </div>
        <div class="row">
          <div class="col">
          <img class="" src="<?php echo e(asset('images/news.jpg')); ?>" alt="" width="100%">
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/dielsurvey/accueil.blade.php ENDPATH**/ ?>