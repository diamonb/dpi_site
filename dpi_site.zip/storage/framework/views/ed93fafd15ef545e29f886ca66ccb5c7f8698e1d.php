
<?php $__env->startSection("content"); ?>

<div class="row">
    <div class="col-md-3">

    </div>
    <div class="col-md-6  text-center mb-2">
            <h2><span class="badge rounded-pill bg-success">Welcome back !</span></h2>
            <h2><span class="">Please click next to configure your accompt!</span></h2>
            <form name="register" id="register" method="post" action="<?php echo e(route('resgister_start_configuration')); ?>">
            <?php echo csrf_field(); ?> 
            <button type="submit" class="btn btn-success">Next</button>
            </form>
    </div>

    <div class="col-md-3">

    </div>
</div>

  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/register/mail_confirmation.blade.php ENDPATH**/ ?>