
<?php $__env->startSection("content"); ?>

<div class="container">
      <p class="text-white bg-dark h4 mt-3">You're process on...</p>
      <div class="row mt-4">
            <div class="col-md-8">
            <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">Service</th>
                <th scope="col">Service description</th>
                <th scope="col">Application fee</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($service->libelle); ?></td>
                    <td><?php echo $service->description; ?></td>
                    <td>50 $</td>
                </tr>
            </tbody>
            </table>

            </div>
            <div class="col-md-4" style="border: 1px solid black">
                  <p class="text-white bg-dark h4 mt-3">Recapitulatif</p>
                  <p><b>Service</b></p>
                  <p><?php echo e($service->libelle); ?>   <b>50 $</b></p> 
                  <hr>
                  <p>TOTAL  50 $</p> 
            </div>
      </div>
</div>

  <div class="">

        
  </div>

   <div class="container digital_class" id="digital">
   <div class="row">


      </div>     
  </div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/pages/service_select_form.blade.php ENDPATH**/ ?>