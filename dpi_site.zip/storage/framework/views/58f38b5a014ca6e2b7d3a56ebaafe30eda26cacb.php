
<?php $__env->startSection("content"); ?>

<div>
    <h2 class="justify-context-center" style="height:250px; background-color:#fcc200">PARTENER</h2>
</div>

<div class="container">
    <div class="row">
        <div class="col">
            <p>We are inviting direct lenders and brokers around the country to join our team.</p>   
            <p>As a lender you can benefit by joining and receiving a constant flow of prospects seeking financing for their business. Expect to increase your funded volume and overall business income.</p>
            <p>As a broker you can benefit by offering our services to your clients. If you secure a deal, you will receive a commission or revenue share. A broker can expect to earn up to 5% of loan amount on funded deals.</p>
        </div>
        <div class="col">
            <img class="rounded" src="<?php echo e(asset('images/business.jpg')); ?>" alt="" width="100%">
        </div>
    </div>
</div>

<div class="container">

    <h3>To get more information about joining our team, fill out the short form and we will contact you shortly.</h2>
    <!--Section: Contact v.2-->
<section class="mb-4">


<div class="row">

    <!--Grid column-->
    <div class="mb-md-0 mb-5 d-flex justify-content-center">
        <div class="col-lg-8">
        <form>
  
            <div class="row mb-4">
                <div class="col">
                <div class="form-outline">
                    <input type="text" id="form3Example1" class="form-control" />
                    <label class="form-label" for="form3Example1">Your name</label>
                </div>
                </div>
                <div class="col">
                <div class="form-outline">
                    <input type="text" id="form3Example2" class="form-control" />
                    <label class="form-label" for="form3Example2">Your email</label>
                </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                <div class="form-outline">
                    <input type="text" id="form3Example1" class="form-control" />
                    <label class="form-label" for="form3Example1">Your compagny</label>
                </div>
                </div>
                <div class="col">
                <div class="form-outline">
                    <input type="text" id="form3Example2" class="form-control" />
                    <label class="form-label" for="form3Example2">Phone number</label>
                </div>
                </div>
            </div>

            <!-- Password input -->
            <div class="form-outline mb-4">
            <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                <label class="form-label" for="form3Example4">Tell us about your project</label>
            </div>


            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block mb-4">Submit</button>


            </form>

        </div>


        
    </div>
    <!--Grid column-->

</section>
<!--Section: Contact v.2-->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/pages/partener.blade.php ENDPATH**/ ?>