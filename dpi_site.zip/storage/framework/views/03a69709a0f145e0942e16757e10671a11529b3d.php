
<?php $__env->startSection("content"); ?>


  <div class="">
        <p class="h1 text-center mt-4">Services</p>
  </div>


<div class="container mt-2">
    <div class="row">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-4">
            <div class="accordion mb-5" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="headingTwo<?php echo e($service->id_service); ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo<?php echo e($service->id_service); ?>" aria-expanded="false" aria-controls="collapseTwo">
                        <strong><?php echo e($service->libelle); ?></strong>
                    </button>
                    </h2>
                    <div id="collapseTwo<?php echo e($service->id_service); ?>" class="accordion-collapse collapse" aria-labelledby="headingTwo<?php echo e($service->id_service); ?>" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        <?php echo $service->description; ?>

                        <p>
                            <form action="<?php echo e(route('service_choose',$service->id_service)); ?>" method ="POST">
                            <?php echo csrf_field(); ?>
                                <button class="btn btn-success">Add to card</button><button class="btn btn-primary">Order now</button>
                            </form>
                        </p>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<!-- plan -->


    <!--<div class="row mt-4">

        <div class="col-lg-2">

        </div>

        <div class="col-lg-8 mb-md-0 mb-5">
            <table class="table">
                <thead class="thead-light">
                    <tr class="table-dark">
                    <th scope="col">Plans Features & Services (Consulting, Assistance & Services)</th>
                    <th scope="col">Basic</th>
                    <th scope="col">Pro</th>
                    <th scope="col">Premium</th>
                    </tr>
                </thead>
                <tbody class="table-secondary">
                    <tr>
                    <th scope="row">
                        <h4>Marketing Strategy</h4>
                        <p>We combine marketing & digital approach to building a playbook around what makes your business unique, helping you to leverage strengths and make greater impact within industry specific markets.</p>
                    </th>
                    <td>x</td>
                    <td>x</td>
                    <td>x</td>
                    </tr>
                    <tr>
                    <th scope="row">
                        <h4>Lifecycle Marketing Service</h4>
                        <p>With the integration and utilization of digital, we will be creating a consumer lifecycle game plan based on your brand and audiences.</p>
                    </th>
                    <td>x</td>
                    <td>x</td>
                    <td>x</td>
                    </tr>
                    <tr>
                    <th scope="row">
                        <h4>Marketing Campaign Implementation</h4>
                        <p>Our team will be committed to design, implement, and support your marketing campaign related projects, helping your brand to successfully deploy and grow.</p>
                    </th>
                    <td>x</td>
                    <td>x</td>
                    <td>x</td>
                    </tr>
                    <tr>
                    <th scope="row">
                        <h4>Branding & Production Services</h4>
                        <p>Combining creative insight and deft design, we develop a visual esthetic to truly distinguish your brand and make it resonate authentic with target audiences</p>
                    </th>
                    <td>x</td>
                    <td>x</td>
                    <td>x</td>
                    </tr>

                    <tr>
                    <th scope="row">
                        <h4>Content & Edition Services</h4>
                        <p>Our team will be providing customized written content and organic social curation, to leverage your SEO insights, to grow your audiences through online engagement and customer experience sensibility.</p>
                    </th>
                    <td>x</td>
                    <td>x</td>
                    <td>x</td>
                    </tr>
                    <th scope="row">
                        <h4>DIELSurvey</h4>
                        <p>DIELSurvey will focus in realizing your online surveys to keep your brand up to date, while understanding and anticipating your clients, stakeholders, and market changes.</p>
                    </th>
                    <td>1/Month</td>
                    <td>2/Month</td>
                    <td>3/Month</td>
                    </tr>
                    <th scope="row">
                        <h4>Dedicated resource</h4>
                        <p>We dedicate a Marketing Consultant resource to assist with your needs and Marketing strategy, implementation, and support journey.</p>
                    </th>
                    <td>1 call/Month (2 hours)</td>
                    <td>2 call/Month (2 hours)</td>
                    <td>4 call/Month (2 hours)</td>
                    </tr>
                    </tr>
                    
                </tbody>
            </table>
            <p class="text-end"><a href="<?php echo e(route('contact')); ?>"><span class="fa fa-arrow-right fs-6"> Let's get started a free DPI MS consultancy now</span></a></p>
        </div>
        <div class="col-lg-2">

        </div>
    </div>-->
<!-- plan -->
</div>


<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/pages/marketing.blade.php ENDPATH**/ ?>