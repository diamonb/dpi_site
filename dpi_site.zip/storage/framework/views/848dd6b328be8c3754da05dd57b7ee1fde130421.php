<!-- Modal testimonial -->
<div class="modal fade" id="testimonialModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">TESTIMONIAL</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
            <div class="row">
              <div class="col">
                <input type="text" class="form-control" placeholder="First name">
              </div>
              <div class="col">
                <input type="text" class="form-control" placeholder="Last name">
              </div>
            </div>
            <div class="row mt-4">
            <div class="form-group">
              <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Domain">
            </div>
            <div class="form-group mt-4">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3">Your testimonial...</textarea>
            </div>
            <div class="form-group mt-4">
              <label for="exampleFormControlFile1">Photo</label>
              <input type="file" class="form-control-file" id="exampleFormControlFile1">
            </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block mb-3 mt-4">Submit</button>
        </form>
      </div>
    </div>
  </div>
</div>


<!-- Modal connexion -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">LOGIN</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <!-- Pills navs -->
<ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link active" id="tab-login" data-mdb-toggle="pill" href="#pills-login" role="tab"
      aria-controls="pills-login" aria-selected="true">Login</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="tab-register" data-mdb-toggle="pill" href="#pills-register" role="tab"
      aria-controls="pills-register" aria-selected="false">Register</a>
  </li>
</ul>
<!-- Pills navs -->

<!-- Pills content -->
<div class="tab-content">
  <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
    <form>
      <div class="text-center mb-3">
        <p>Sign in with:</p>
        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-facebook-f"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-google"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-twitter"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-linkedin"></i>
        </button>
      </div>

      <p class="text-center">or:</p>

      <!-- Email input -->
      <div class="form-outline mb-4">
        <input type="email" id="loginName" class="form-control" />
        <label class="form-label" for="loginName">Email or username</label>
      </div>

      <!-- Password input -->
      <div class="form-outline mb-4">
        <input type="password" id="loginPassword" class="form-control" />
        <label class="form-label" for="loginPassword">Password</label>
      </div>

      <!-- 2 column grid layout -->
      <div class="row mb-4">
        <div class="col-md-6 d-flex justify-content-center">
          <!-- Checkbox -->
          <div class="form-check mb-3 mb-md-0">
            <input class="form-check-input" type="checkbox" value="" id="loginCheck" checked />
            <label class="form-check-label" for="loginCheck"> Remember me </label>
          </div>
        </div>

        <div class="col-md-6 d-flex justify-content-center">
          <!-- Simple link -->
          <a href="#!">Forgot password?</a>
        </div>
      </div>

      <!-- Submit button -->
      <button type="submit" class="btn btn-primary btn-block mb-4">Sign in</button>

      <!-- Register buttons -->
      <div class="text-center">
        <p>Not a member? <a href="#!">Register</a></p>
      </div>
    </form>
  </div>
  <div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register">
    <form name="register" id="register" method="post" action="<?php echo e(route('register_form')); ?>">
    <?php echo csrf_field(); ?> 
      <div class="text-center mb-3">
        <p>Sign up with:</p>
        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-facebook-f"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-google"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-twitter"></i>
        </button>

        <button type="button" class="btn btn-link btn-floating mx-1">
          <i class="fab fa-linkedin"></i>
        </button>
      </div>

      <p class="text-center">or:</p>

      <!-- Name input -->
      <div class="form-outline mb-4">
        <input type="text" name="name" id="registerName" class="form-control" />
        <label class="form-label"  for="registerName">Full name</label>
      </div>

      <!-- Username input -->
      <div class="form-outline mb-4">
        <input type="text" name="username" id="registerUsername" class="form-control" />
        <label class="form-label" for="registerUsername">Username</label>
      </div>

      <!-- Email input -->
      <div class="form-outline mb-4">
        <input type="email" name="email"  id="registerEmail" class="form-control" />
        <label class="form-label" for="registerEmail">Email</label>
      </div>
      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

      <!-- Password input -->
      <div class="form-outline mb-4">
        <input type="password" name="password"  id="registerPassword" class="form-control" />
        <label class="form-label" for="registerPassword">Password</label>
      </div>
      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

      <!-- Repeat Password input -->
      <div class="form-outline mb-4">
        <input type="password" name="password_confirm" id="registerRepeatPassword" class="form-control" />
        <label class="form-label" for="registerRepeatPassword">Repeat password</label>
      </div>

      <!-- Checkbox -->
      <div class="form-check d-flex justify-content-center mb-4">
        <input class="form-check-input me-2" type="checkbox" value="" id="registerCheck" checked
          aria-describedby="registerCheckHelpText" />
        <label class="form-check-label" for="registerCheck">
          I have read and agree to the terms
        </label>
      </div>

      <!-- Submit button -->
      <button type="submit" class="btn btn-primary btn-block mb-3">Sign in</button>
    </form>
  </div>
</div>
<!-- Pills content -->
      </div>
    </div>
  </div>
</div>

<div id="top-bar">
    
</div>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="navbar_top">
  <!-- Container wrapper -->
  <div class="container">
    <!-- Navbar brand -->
    <a class="navbar-brand me-2" href="<?php echo e(route('accueildpi')); ?>">
      <img
        src="<?php echo e(asset('images/logo.jpeg')); ?>"
        height="52"
        alt="DPI Logo"
        loading="lazy"
        style="margin-top: -1px;"
      />
    </a>

    <!-- Toggle button -->
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarButtonsExample"
      aria-controls="navbarButtonsExample"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <i class="fas fa-bars"></i>
    </button>

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbarButtonsExample">
      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          
        </li>
      </ul>
      <!-- Left links -->

      <div class="d-flex align-items-center">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('accueilreference')); ?>" tabindex="-1" >Home</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Services
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="<?php echo e(route('accueilmarketing')); ?>">DPI Marketing</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('accueilfinance')); ?>">DPI Finance</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('accueildigital')); ?>">DPI Digital</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" target="_blank" href="<?php echo e(route('dielshop')); ?>" tabindex="-1" >DIELShop</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('accueilreference')); ?>" tabindex="-1" >References</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              About
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="<?php echo e(route('about_vmvo')); ?>">VMVO</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('about_company')); ?>">Company</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('about_when_call')); ?>">When call for DPI?</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('about_leadership')); ?>">Leadership</a></li>
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('dielsurvey')); ?>" tabindex="-1" >DIELSurvey</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('contact')); ?>" tabindex="-1" >Contact</a>
            </li>
          </ul>
        <i data-mdb-toggle="tooltip" title="Shopping card" data-bs-toggle="modal" data-bs-target="#loginModal"  class="fas fa-shopping-cart  fa-lg ms-4 text-white"></i>
        <i data-mdb-toggle="tooltip" title="Login" data-bs-toggle="modal" data-bs-target="#loginModal"  class="fas fa-sign-in-alt  fa-lg ms-5 text-white"></i>
        <i data-mdb-toggle="tooltip" title="Search" data-bs-toggle="modal" data-bs-target="#loginModal"  class="fas fa-search  fa-lg ms-3 text-white"></i>
        
        
      </div>
    </div>
    <!-- Collapsible wrapper -->
  </div>
  <!-- Container wrapper -->
</nav><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/partials/head.blade.php ENDPATH**/ ?>