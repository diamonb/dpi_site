
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Privacy Policy  </p>
    
  </div>
<div class="container">
<br><span class="h4 mt-5">Privacy Policy</span><br>
    <p>
    
This privacy policy has been compiled to better serve those who are concerned with how their ‘Personally Identifiable Information’ (PII) is being used online. PII, as described in US privacy law and information security, is information that can be used on its own or with other information to identify, contact, or locate a single person, or to identify an individual in context. Please read our privacy policy carefully to get a clear understanding of how we collect, use, protect or otherwise handle your Personally Identifiable Information in accordance with our website.

<br><span class="h4 mt-5">What personal information do we collect from the people that visit our blog, website, or app?</span><br>

When ordering or registering on our site, as appropriate, you may be asked to enter your name, email address, mailing address, phone number or other details to help you with your experience.

<br><span class="h4 mt-5">When do we collect information?</span><br>

We collect information from you when you register on our site, subscribe to a newsletter, fill out a form or enter information on our site.
<br><span class="h4 mt-5">How do we use your information?</span><br>

We may use the information we collect from you when you register, make a purchase, sign up for our newsletter, respond to a survey or marketing communication, surf the website, or use certain other site features in the following ways:
•	To allow us to better service you in responding to your customer service requests.
•	To send periodic emails regarding your order or other products and services.
•	To follow up with them after correspondence (live chat, email, or phone inquiries)
<br><span class="h4 mt-5">How do we protect your information?</span><br>

Our website is scanned on a regular basis for security holes and known vulnerabilities in order to make your visit to our site as safe as possible.
We only provide articles and information. We never ask for personal or private information like credit card numbers.
This additional utility positions this product to capture the existing market share of pointing devices. Additional finger-units attached to different fingers offer complex gesture recognition capabilities making this product an ideal controller for video games, Virtual Reality platform, etc.
<br><span class="h4 mt-5">Do we use ‘cookies?</span><br>

We do not use cookies for tracking purposes.
You can choose to have your computer warn you each time a cookie is being sent, or you can choose to turn off all cookies. You do this through your browser settings. Since browser is a little different, look at your browser’s Help Menu to learn the correct way to modify your cookies.
If you turn cookies off, some features will be disabled that make your site experience more efficient and may not function properly.

<br><span class="h4 mt-5">Third-party disclosure</span><br>

We do not sell, trade, or otherwise transfer to outside parties your Personally Identifiable Information.

<br><span class="h4 mt-5">Third-party links</span><br>

We do not include or offer third-party products or services on our website.
<br><span class="h4 mt-5">Google</span><br>

We have not enabled Google AdSense on our site, but we may do so in the future.

<br><span class="h4 mt-5">COPPA (Children Online Privacy Protection Act)</span><br>

When it comes to the collection of personal information from children under the age of 13 years old, the Children’s Online Privacy Protection Act (COPPA) puts parents in control. The Federal Trade Commission, United States’ consumer protection agency, enforces the COPPA Rule, which spells out what operators of websites and online services must do to protect children’s privacy and safety online.
We do not specifically market to children under the age of 13 years old.

<br><span class="h4 mt-5">Contacting Us</span><br>

If there are any questions regarding this privacy policy, you may contact us using the information below.
<br> <br>
DPI USA LLC <br>
17350 State Hwy 249 <br>
Houston <br>
TX 77064 <br>
USA <br>
dpi@dielpi.com 


    </p>
</div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/pages/privacy_policy.blade.php ENDPATH**/ ?>