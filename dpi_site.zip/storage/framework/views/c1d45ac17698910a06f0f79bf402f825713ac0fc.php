
<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12">
            <h2 class="m-lg-4">List of surveys</i></h2>

        </div>

    </div>
    <div class="row">
            <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">Survey title</th>
                <th scope="col">Survey description</th>
                <th scope="col">Survey link</th>
                <th scope="col">Survey image</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($survey->title); ?></td>
                    <td><?php echo $survey->description; ?></td>
                    <td><?php echo e($survey->link); ?></td>
                    <td><img src="<?php echo e(asset($survey->image)); ?>" alt="photo" class="img img-thumbnail"></td>
                    <td><button class="btn btn-danger">Delete</button>&nbsp;&nbsp;<button class="btn btn-success">Update</button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/admin/list_survey.blade.php ENDPATH**/ ?>