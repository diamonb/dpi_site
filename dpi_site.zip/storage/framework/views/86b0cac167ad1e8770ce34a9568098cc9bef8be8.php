
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Shipping Policy  </p>
    
  </div>
<div class="container">
    <br><span class="h4 mt-5">Shipping Policy</span><br>   
    <p>
    The orders are processed and shipped within 1-2 business days. We will contact the customer through email/phone number in case of any additional delays. An email notification will be sent containing the tracking number once the order is confirmed and shipped. The rates are displayed in US dollars. Please make use of an online converter if needed.
    <br><span class="h4 mt-5">Domestic Shipments</span><br>  
        
        Shipments within the United States qualify for free shipping.
    <br><span class="h4 mt-5">International Shipments</span><br>  
        
        We ship internationally. The international shipping carrier is DHL. The shipping rates are calculated and displayed on the checkout page along with an estimated delivery date. We offer Saturday deliveries.
        •	Delivery delays can occasionally happen.
        Please contact the shipping carrier if you experience any extra delay.
        The order may be subject to customs clearance charges, and we are not responsible for these additional charges.
        <br><span class="h4 mt-5">Payment</span><br>  
        Payments can be done from credit/debit cards or mobile. We do not offer cash on deliveries.
        <br><span class="h4 mt-5">Contact</span><br>  
        
        For any questions regarding the shipment, contact us at shipping@dielpi.com 

            </p>
</div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/pages/shipping_policy.blade.php ENDPATH**/ ?>