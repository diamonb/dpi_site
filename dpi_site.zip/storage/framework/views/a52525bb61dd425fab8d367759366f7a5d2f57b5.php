
<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12">
            <h2 class="m-lg-4">Welcome</i></h2>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/admin/accueil.blade.php ENDPATH**/ ?>