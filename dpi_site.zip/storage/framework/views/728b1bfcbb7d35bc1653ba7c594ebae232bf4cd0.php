
<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12">
            <h2 class="m-lg-4">Contacts</i></h2>

        </div>

    </div>
    <div class="row">
            <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">First name</th>
                <th scope="col">Last name</th>
                <th scope="col">Domain</th>
                <th scope="col">Testimonial</th>
                <th scope="col">Image</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
     
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($testimonial->first_name); ?></td>
                    <td><?php echo e($testimonial->last_name); ?></td>
                    <td><?php echo e($testimonial->domain); ?></td>
                    <td><?php echo e($testimonial->testimonial); ?> </td>
                    <td><img src="<?php echo e(asset($testimonial->photo)); ?>" alt="photo"></td>
                    <td><form method="POST" action="<?php echo e(route('share_testimonial')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id_testimonial" value="<?php echo e($testimonial->id_testimonial); ?>"/>
                        <button class="btn btn-success">Share</button>
                    </form>
                    <form action=""><button class="btn btn-danger">Delete</button></form>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/user/list_testimonial.blade.php ENDPATH**/ ?>