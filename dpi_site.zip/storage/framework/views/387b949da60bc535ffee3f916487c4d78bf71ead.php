
<?php $__env->startSection("content"); ?>
<!-- carousel-->
<div class="container">

</div>

      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" >
        <div class="carousel-inner">

          <!--<div class="carousel-item active ca1">
          <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-white">
                    <span class="">Business consulting firm providing marketing, <br> finance & digital service and solutions for your growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>-->

          <div class="carousel-item active ca2">
          <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-success">
                    <span class="">Digital business consulting <br>Providing exceptional service and digital solutions for your business growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>


          <div class="carousel-item ca3">
            <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-primary">
                    <span class="">Financial Business Consulting <br>Providing exceptional service and financial solutions for your business growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>

          <div class="carousel-item ca4">
            <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-danger">
                    <span class="">Marketing business consulting<br>Providing exceptional service and marketing solutions for your business growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="" aria-hidden="true"><i class="fas fa-angle-left fa-5x text-white"></i></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="" aria-hidden="true"><i class="fas fa-angle-right fa-5x text-white"></i></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    
    <div class="container ourcompagny">
      <div class="row">
        <div class="col-md-1">

        </div>
        <div class="col-md-10 colOurcompagny lh-md" id="dpi">
          DIEL Partners International (DPI) is an International Business Consulting & Services Firm, providing tailored high added value Services and Solutions in Marketing, Finance & Digital. We help our Clients with their project development and implementation, while improving their Productivity, Profitability, and Performance.

          <p><b>DPI is a Marketing, Finance & Finance Business Consulting Company based in Houston, Texas.</b></p> <br>
          <!--<button type="button" class="btn btn-primary btn-sm"><span class="bi-plus-square-fill"></span>&nbsp;Add</button>
          <button type="button" class="btn btn-secondary"><span class="bi-search"></span>&nbsp;Search</button>
          <button type="button" class="btn btn-danger"><span class="bi-trash"></span>&nbsp;Delete</button>-->
        </div>
        <div class="col-md-1">

        </div>
     

      </div>

      
    </div>
    
    <div class="" style="">
      <div class="container">
          </div>
        </div>
        <h4 class="text-center mt-5 mb-5"></h4>

        <div class="container-fluid mb-5" data-aos="fade-up">
          <div class="row justify-content-center">
            <div class="col-6">

                  <img class="rounded" src="<?php echo e(asset('images/business.jpg')); ?>" alt="" width="100%">

            </div>
            <div class="col-2  ms-5">

             <p class="mt-1 mb-1 fs-5">
              <b class="fs-2">We are a… </b> <br> Creative, Agile and Iterative Team… <br>
              Focus on both Customer and Business experiences success…
             </p>  
             <p class="mt-5">
             <b class="fs-2">We have been helping…</b>
             <p class="fs-5">Small, Medium Businesses with  their Marketing, Finance & Digital related projects development, implementations and support for years…</p>

             </p>


            </div>
          </div>
        </div>

        <div class="container marketing_class" id="marketing">
          <div class="row justify-content-center">
            <div class="col-4 marketing_text" data-aos="fade-right">
              <div class="row justify-content-center">
                  <div class="col-10 mt-5 text-white">
                    <p class="fs-3">Your Marketing Business Consulting Partner!</p>
                    <p class="fs-6 mt-4">We have been helping Small/Medium Businesses with their marketing strategy, project development and implementation for years, you are our next success story!</p>
                    <a href="#"><span class="fa fa-arrow-right fs-6"> Learn more...</span></a>
                  </div>
              </div>
             
            </div>
            <div class="col-8" data-aos="fade-left">
              <img class="" src="<?php echo e(asset('images/visual.jpg')); ?>" alt="" width="100%">
            </div>
            
          </div>
        </div>
        
        <div class="container-fluid mb-5 finance_class" id="finance">
          <div class="row justify-content-center">
            <div class="col-6" data-aos="fade-right">

                  <img class="rounded" src="<?php echo e(asset('images/finance.jpg')); ?>" alt="" width="100%">

            </div>
            <div class="col-4 finance_text" data-aos="fade-left">
              <div class="row justify-content-center">
                  <div class="col-10 mt-5 text-white">
                    <p class="fs-3">Your Finance Business Consulting Partner!</p>
                    <p class="fs-6 mt-4"> We have been helping Small/Medium with their project funding, financial services and solutions for years, you are our next success story!</p>
                    <a href="#"><span class="fa fa-arrow-right fs-6"> Learn more...</span></a>
                  </div>
              </div>
          </div>
        </div>

        <div class="container digital_class" id="digital">
          <div class="row justify-content-center">
            <div class="col-4 digital_text" data-aos="fade-right">
              <div class="row justify-content-center">
                  <div class="col-10 mt-5 text-white">
                    <p class="fs-3">Your Digital Business Consulting Partner!</p>
                    <p class="fs-6 mt-4">We have been helping Small/Medium Businesses with their Digital Project development, implementation and support for years, you are our next success story!</p>
                    <a href="#"><span class="fa fa-arrow-right fs-6"> Learn more...</span></a>
                  </div>
              </div>
             
            </div>
            <div class="col-8" data-aos="fade-left">
              <img class="" src="<?php echo e(asset('images/visual.jpg')); ?>" alt="" width="100%">
            </div>
            
          </div>
        </div>

      
    </div>
    <hr>
    <div class="container-fluid">

      <!-- Carousel wrapper -->
<div id="carouselMultiItemExample" class="carousel slide carousel-dark text-center" data-mdb-ride="carousel">
  <!-- Controls -->
  <div class="d-flex justify-content-center mb-4">
    <button class="carousel-control-prev position-relative" type="button"
      data-mdb-target="#carouselMultiItemExample" data-mdb-slide="prev">
      <span aria-hidden="true"><i class="fas fa-angle-left fa-lg text-black"></i></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next position-relative" type="button"
      data-mdb-target="#carouselMultiItemExample" data-mdb-slide="next">
      <span aria-hidden="true"><i class="fas fa-angle-right fa-lg text-black"></i></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  <!-- Inner -->
  <div class="carousel-inner py-4">
    <!-- Single item -->
    <div class="carousel-item active">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(1).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">Anna Deynah</h5>
            <p>UX Designer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod eos id
              officiis hic tenetur quae quaerat ad velit ab hic tenetur.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
            </ul>
          </div>

          <div class="col-lg-4 d-none d-lg-block">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(32).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">John Doe</h5>
            <p>Web Developer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis
              suscipit laboriosam, nisi ut aliquid commodi.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li>
                <i class="fas fa-star-half-alt fa-sm"></i>
              </li>
            </ul>
          </div>

          <div class="col-lg-4 d-none d-lg-block">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(10).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">Maria Kate</h5>
            <p>Photographer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
              praesentium voluptatum deleniti atque corrupti.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="far fa-star fa-sm"></i></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Single item -->
    <div class="carousel-item">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(3).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">John Doe</h5>
            <p>UX Designer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod eos id
              officiis hic tenetur quae quaerat ad velit ab hic tenetur.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
            </ul>
          </div>

          <div class="col-lg-4 d-none d-lg-block">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(4).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">Alex Rey</h5>
            <p>Web Developer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis
              suscipit laboriosam, nisi ut aliquid commodi.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li>
                <i class="fas fa-star-half-alt fa-sm"></i>
              </li>
            </ul>
          </div>

          <div class="col-lg-4 d-none d-lg-block">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(5).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">Maria Kate</h5>
            <p>Photographer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
              praesentium voluptatum deleniti atque corrupti.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="far fa-star fa-sm"></i></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Single item -->
    <div class="carousel-item">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(6).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">Anna Deynah</h5>
            <p>UX Designer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod eos id
              officiis hic tenetur quae quaerat ad velit ab hic tenetur.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
            </ul>
          </div>

          <div class="col-lg-4 d-none d-lg-block">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(8).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">John Doe</h5>
            <p>Web Developer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis
              suscipit laboriosam, nisi ut aliquid commodi.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li>
                <i class="fas fa-star-half-alt fa-sm"></i>
              </li>
            </ul>
          </div>

          <div class="col-lg-4 d-none d-lg-block">
            <img class="rounded-circle shadow-1-strong mb-4"
              src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/img%20(7).webp" alt="avatar"
              style="width: 150px;" />
            <h5 class="mb-3">Maria Kate</h5>
            <p>Photographer</p>
            <p class="text-muted">
              <i class="fas fa-quote-left pe-2"></i>
              At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
              praesentium voluptatum deleniti atque corrupti.
            </p>
            <ul class="list-unstyled d-flex justify-content-center text-warning mb-0">
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="fas fa-star fa-sm"></i></li>
              <li><i class="far fa-star fa-sm"></i></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Inner -->
</div>
<div>
    <p class="text-center"><span class="btn btn-success" data-bs-toggle="modal" data-bs-target="#testimonialModal">Share your testimonial</span></p>
</div>
<!-- Carousel wrapper -->
</div>
       <!-- Footer -->
<?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/accueil.blade.php ENDPATH**/ ?>