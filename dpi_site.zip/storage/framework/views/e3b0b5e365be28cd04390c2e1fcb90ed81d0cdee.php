
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">DIELSurvey</p>
    
  </div>
  <div class="container">
    <div class="row mt-4 mb-4">
          <div class="col">
          </div>
          <div class="col">
            <div class="input-group">
            <div class="form-outline">
              <input type="search" id="form1" class="form-control" />
              <label class="form-label" for="form1">Search a DIELSurvey here</label>
            </div>
            <button type="button" class="btn btn-primary">
              <i class="fas fa-search"></i>
            </button>
            </div>
          </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <div class="entete_column">
              <p class="text-center h3">Insights</p>
        </div>
        <?php $__currentLoopData = $insights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-md-10">
            <p><b><?php echo e($insight->title); ?></b></p>
            <p><small><?php echo $insight->description; ?></small></p>
          </div>
          <div class="col-md-2">
            <a class="" href="<?php echo e(asset($insight->file)); ?>" download><i data-mdb-toggle="tooltip" title="Download insight" class="justify-content-end fas fa-download"></i></a>
          </div>
        </div>         
          <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="col-md-6">
        <div class="entete_column">
              <p class="text-center h3">Surveys</p>
        </div>
        <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-md-4">
          <img class="" src="<?php echo e(asset($survey->image)); ?>" alt="" width="100%">
          </div>
          <div class="col-md-8">
              <p><b><?php echo e($survey->title); ?></b> </p>
              <p><?php echo $survey->description; ?></p>
              <p class="text-end"><i data-mdb-toggle="tooltip" title="Share" class="fas fa-share fa-2x text-success"></i> 
              <button shout-button
              class="btn btn-outline-primary"
              data-sh-form="<?php echo e($survey->link); ?>"
              data-sh-close-on-complete="false"
              data-sh-type="slideout"
              data-sh-direction="right"
              sh-initial-color="#2A98C6"> Take this DIELSurvey</button>
            </p>
          </div>
        </div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo $surveys->links(); ?>

      </div>
      <div class="col-md-3">
        <div class="entete_column">
              <p class="text-center h3">News</p>
        </div>
        <div class="row">
          <div class="col">
          <img class="" src="<?php echo e(asset('images/news.jpg')); ?>" alt="" width="100%">
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
  <button class="btn btn-primary d-flex p-2" type="button"><i class="material-icons pmd-sm">Become participant</i></button>
<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\mesprojets\production\dpi_site\resources\views/dielsurvey/accueil.blade.php ENDPATH**/ ?>