
<?php $__env->startSection("content"); ?>

<div class="row">
<div class="col-md-3 side_1">

</div>
<div class="col-md-6  side_2">
            <div class="text-center mt-3">
                <h5>We have sent you a mail on <span class="badge badge-secondary"><?php echo e(session('email')); ?></span> check it out to confirm your registration</h5>
            </div>
            <p class="text-center"><span><a href="<?php echo e(route('accueildpi')); ?>"><i class="fas fa-long-arrow-alt-left"></i> Go back to Home</a></span></p>
</div>
<div class="col-md-3 side_1">

</div>
</div>

  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/register/mail_confirm.blade.php ENDPATH**/ ?>