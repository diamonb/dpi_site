
<?php $__env->startSection("content"); ?>
<!-- carousel-->
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" >
        <div class="carousel-inner">

          <!--<div class="carousel-item active ca1">
          <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-white">
                    <span class="">Business consulting firm providing marketing, <br> finance & digital service and solutions for your growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>-->

          <div class="carousel-item active ca2">
          <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-success">
                    <span class="">Digital business consulting <br>Providing exceptional service and digital solutions for your business growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>


          <div class="carousel-item ca3">
            <div class="container-fluid">
              <div class="row">
                <div class="col animate__animated animate__rubberBand fs-4 fw-bolder text-primary">
                    <span class="">Financial Business Consulting <br>Providing exceptional service and financial solutions for your business growth</span>
                </div>
                <div class="col">

                </div>
                <div class="col">

                </div>
              </div>
            </div>
          </div>

          <div class="carousel-item ca4">
            <div class="container-fluid">
              <div class="row">
                <div class="col  text-danger">
                    
                </div>
                <div class="col">
                 
                </div>
                <div class="col animate__animated animate__rubberBand  col fs-4 fw-bolder">
                  <span class=""><a target="_blank" href="https://book.texasblackexpo.com/vendorbooth">Expo</a>  </span>
                </div>
              </div>
            </div>
          </div>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="" aria-hidden="true"><i class="fas fa-angle-left fa-5x text-white"></i></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="" aria-hidden="true"><i class="fas fa-angle-right fa-5x text-white"></i></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    
    <div class="container ourcompagny">
      <div class="row">
        <div class="col-md-1">

        </div>
        <div class="col-md-10 colOurcompagny lh-md" id="dpi">
          DIEL Partners International (DPI) is an International Business Consulting & Services Firm, providing tailored high added value Services and Solutions in Marketing, Finance & Digital.
          We help our Clients with their project development and implementation, while improving their Productivity, Profitability, and Performance.

          <p><b>DPI is a Marketing, Financial & Digital Business Consulting Company based in Houston, Texas.</b></p> <br>
        </div>
        <div class="col-md-1">

        </div>
     

      </div>  
    </div>
    <div class="container">
      <div class="row ">
            <div class="col-lg-6">

                  <img class="rounded" src="<?php echo e(asset('images/business.jpg')); ?>" alt="" width="100%">

            </div>
            <div class="col-lg-6">

             <p class="mt-2 mb-1 fs-5">
              <b class="fs-2">We are a… </b> <br> Creative, Agile and Iterative Team… <br>
              Focus on both Customer and Business experiences success…
             </p>  
             <p class="mt-3">
             <b class="fs-2">We have been helping…</b>
             <p class="fs-5">Small, Medium Businesses with  their Marketing, Finance & Digital related projects development, implementations and support for years…</p>
             
             <p class="mt-3">
             <b class="fs-2">We combine...</b>
             <p class="fs-5">Marketing, Financial & Digital Service and Solutions approach to addressing our clients’ must painfully challenges, while transforming them in Great Growth opportunities.</p>
             
             </p>


            </div>
        </div>
    </div>
        

        <div class="container">
          <div class="row marketing_class" id="marketing">
            <div class="col-lg-6 marketing_text text-white" data-aos="fade-right">
                    <p class="fs-3">Your Marketing Business Consulting Partner!</p>
                    <p class="fs-6 pt-4">We have been helping Small/Medium Businesses with their marketing strategy, project development and implementation for years, you are our next success story!</p>
                    <p>Our Marketing service & solutions Agency DPI MS is commented in helping small and medium businesses to developing and extending their brands, products, and services in their respective lifecycle, while impowering and improving both their business and customers experiences. </p>
                    <h2>When to call for DPI MS?</h2>
                    Call DPI MS for your marketing consulting, assistance & services.
                    <ul>
                      <li>Proven marketing consultant</li>
                      <li>Proven marketing consulting team</li>
                      <li>New Ideas about your marketing</li>
                      <li>Extra miles with your existing/new marketing project development support</li>
                      <li>New/existing marketing project design, implementation, and support</li>
                      <li>Insight about your market, research, studies & surveys</li>
                      <li>New/existing products, services & solutions positioning and development. </li>
                      <li>Branding & communication strategy </li>
                      <li>Digital marketing</li>
                      <li>Content edition and design</li>
                      <li>And more</li>
                    </ul>
                    <a href="<?php echo e(route('marketing')); ?>"><span class="fa fa-arrow-right fs-6">Learn more...</span></a>
                    <p><a href="<?php echo e(route('contact')); ?>">Let's get started a free DPI MS consultancy now.</a></p>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
              <img class="" src="<?php echo e(asset('images/visual.jpg')); ?>" alt="" width="100%">
            </div>
         </div>   
        </div>
        
        <div class="container finance_class" id="finance">
          <div class="row">
            <div class="col-lg-6" data-aos="fade-right">

                  <img class="rounded" src="<?php echo e(asset('images/finance.jpg')); ?>" alt="" width="100%">

            </div>
            <div class="col-lg-6 finance_text text-white" data-aos="fade-left">
                    <p class="fs-3">Your Financial Business Consulting Partner!</p>
                    <p class="fs-6 mt-4"> We have been helping Small/Medium with their project funding, financial services and solutions for years, 
                      you are our next success story!</p>
                      <p>Our Financial services & solutions Agency DPI Fin. is committed in providing funding project assistance, services, and Solutions, while helping both business owners and individuals customer’s base with their needs.</p>
                    <h2>When to call for DPI Fin.?</h2>
                      All DPI Fin. for your financial & founding consulting, assistance, and services.
                      <ul>
                      <li>Financial consulting</li>
                      <li>Financial service & solutions</li>
                      <li>Business loan services</li>
                      <li>Investment assistance & services</li>
                      <li>Investing in Africa assistance & services</li>
                      <li>Investing in the US assistance & services</li>
                      <li>Paiement service & solutions</li>
                      <li>And more</li>
                    </ul>
                    <a href="<?php echo e(route('finance')); ?>"><span class="fa fa-arrow-right fs-6">Learn more...</span></a>
                    <p><a href="<?php echo e(route('contact')); ?>"><span class="fa fa-arrow-right fs-6">Let's get started a free DPI Fin. consultancy now</span></a></p>
          </div>
        </div>

        <div class="container digital_class" id="digital">
          <div class="row">
            <div class="col-lg-6 digital_text text-white" data-aos="fade-right">
                    <p class="fs-3">Your Digital Business Consulting Partner!</p>
                    <p class="fs-6 mt-4">We have been helping Small/Medium Businesses with their Digital Project development, implementation and support for years, you are our next success story!</p>
                    <p>Our Digital service & solutions Agency DPI Digital is commented in helping small and medium businesses to developing and extending their brands, products, and services in their respective lifecycle, thanks to the integration and utilization of digital. </p>
                    <h2>When to call for DPI Digital?</h2>
                    Call DPI Digital for your Digital service & solutions’ project need.
                    <ul>
                      <li>Digital consulting</li>
                      <li>Digital strategy design</li>
                      <li>Web design services</li>
                      <li>Digital service & solutions</li>
                      <li>Digital project development</li>
                      <li>Digital transition & Integration services</li>
                      <li>Digital Tool & solutions</li>
                      <li>Digital project implementation and support</li>
                      <li>Digital technical partnership assistance services</li>
                      <li>Training & certification programs services</li>
                      <li>And more</li>
                    </ul>
                    <a href="<?php echo e(route('digital')); ?>"><span class="fa fa-arrow-right fs-6">Learn more...</span></a>
                    <p><a href="<?php echo e(route('contact')); ?>"><span class="fa fa-arrow-right fs-6"> Let's get started a free DPI Digital consultancy now</span></a></p>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
              <img class="" src="<?php echo e(asset('images/visual.jpg')); ?>" alt="" width="100%">
            </div>
          </div>         
        </div>
        </div>
<div>


<?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\mesprojets\production\dpi_site\resources\views/accueil.blade.php ENDPATH**/ ?>