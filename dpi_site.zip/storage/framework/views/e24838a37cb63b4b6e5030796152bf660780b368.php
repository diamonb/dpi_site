<!DOCTYPE html>
<html>
<head>
 <title>Laravel 9 Send Email Example</title>
</head>
<body>
 
 <h1>This is test mail from Tutsmake.com</h1>
 
</body>
</html> <?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/mails/inscription.blade.php ENDPATH**/ ?>