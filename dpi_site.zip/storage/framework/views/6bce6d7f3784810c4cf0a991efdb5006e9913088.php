
<?php $__env->startSection("content"); ?>

<div class="row">
<div class="col-md-3 side_1">

</div>
<div class="col-md-6  side_2">
            <div class="col text-center">
              <img src="<?php echo e(asset('images/icons/icons_done.gif')); ?>" alt="">
            </div>
            
            <div class="text-center mt-3 ">
                <h1><span class="badge rounded-pill bg-success">Thank you for sharing your testimonial with us... </span></h1>
                <span><a href="<?php echo e(route('accueildpi')); ?>"><i class="fas fa-long-arrow-alt-left"></i> Go back to Home</a></span>
            </div>
            <p class="text-center"></p> 
</div>
<div class="col-md-3 side_1">

</div>
</div>


  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/confirm_testimonial.blade.php ENDPATH**/ ?>