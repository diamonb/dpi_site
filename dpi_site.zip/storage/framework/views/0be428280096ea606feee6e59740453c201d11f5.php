<button onclick="topFunction()" id="myBtn" title="Go to top"> <i class="fas fa-angle-up fa-lg ms-4 text-white pe-4"></i></button>
<hr>
<div class="container" id="reference">
  <h2>Reference & Partners</h2>
   <section class="customer-logos slider">
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/fundwise.png')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/cannabiz.png')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/ophra.png')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/yield4.jpg')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/markis.png')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/kantar.jpg')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/nielsen.png')); ?>"></div>
      <div class="slide"><img src="<?php echo e(asset('images/partenaires/ipsos.jpg')); ?>"></div>
     
   </section>
</div>

<footer class="bg-dark text-center text-white">
  <!-- Grid container -->
  <div class="container p-4">


    <section class="mt-4">
    <a class="text-white" href="<?php echo e(route('accueilreference')); ?>">Home |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('accueilmarketing')); ?>">DPI Marketing |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('accueilfinance')); ?>">DPI Finance |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('accueildigital')); ?>">DPI Digital |</a>
    <a class="ms-2 text-white" target="_blank" href="https://dielshop.printify.me/products">Shop |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('dielsurvey')); ?>">DIELSurvey |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('about_vmvo')); ?>">VMVO |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('about_company')); ?>">Company |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('about_when_call')); ?>">When call for DPI? |</a>
    <a class="ms-2 text-white" href="<?php echo e(route('about_leadership')); ?>">Leadership |</a>  
    <a class="ms-2 text-white" href="<?php echo e(route('contact')); ?>" >Contact</a>

    </section>

    <section class="mb-6 mt-2">
    <a class="" target="_blank" href="<?php echo e(route('dobusiness')); ?>">Do business with us |</a>
    <a class="" target="_blank" href="<?php echo e(route('consultant')); ?>"> Become a Consultant |</a>
    <a class="" target="_blank" href="<?php echo e(route('partner')); ?>">Partner with us |</a>
    <a class="" target="_blank" href="<?php echo e(route('founder')); ?>">Become a Founder |</a>
    <a class="" target="_blank" href="<?php echo e(route('investwithus')); ?>">Invest with us |</a>
    <a class="" target="_blank" href="<?php echo e(route('sponsor')); ?>">Sponsor/Donate |</a>
    <a class="" target="_blank" href="<?php echo e(route('career')); ?>">Career</a>
 



    </section>
    <section class="">
    <div class="row">
      <div class="col-md-12">
      <?php if($message = Session::get('erreur')): ?>

      <div class="alert alert-danger ">

          <button type="button" class="close" data-dismiss="alert">×</button>

          <strong><?php echo e($message); ?></strong>

      </div>

      <?php endif; ?>
      <?php if($message = Session::get('success')): ?>

      <div class="alert alert-success ">

          <button type="button" class="close" data-dismiss="alert">×</button>

          <strong><?php echo e($message); ?></strong>

      </div>

      <?php endif; ?>
      </div>

    </div>
    
    </section>
    <!-- Section: Form -->
    <section class="">
      <form action="<?php echo e(route('subscibe_newsletter')); ?>" method="POST">
        <!--Grid row-->
        <div class="row d-flex justify-content-center">
          <!--Grid column-->
          <div class="col-auto">
            <p class="pt-2">
              <strong>Newsletter</strong>
            </p>
          </div>
          <!--Grid column-->
          <?php echo e(csrf_field()); ?>

          <!--Grid column-->
          <div class="col-md-5 col-12">
            <!-- Email input -->
            <div class="form-outline form-white mb-4">
              <input type="email" name="email" id="form5Example21" class="form-control" />
              <label class="form-label" for="form5Example21">Email address</label>
            </div>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-auto">
            <!-- Submit button -->
            <button type="submit" class="btn btn-outline-light mb-4">
              Subscribe
            </button>
          </div>

          <!--Grid column-->
        </div>
        <!--Grid row-->
      </form>
    </section>

    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Facebook -->
      <a  data-mdb-toggle="tooltip" title="Facebook" class="btn btn-outline-light btn-floating m-1"  target="_blank" href="https://www.facebook.com/dielpartnersinternational" role="button"
        ><i class="fab fa-facebook-f"></i>
      </a>
            <!-- whatsap -->
      <a  data-mdb-toggle="tooltip" title="Whatsapp" class="btn btn-outline-light btn-floating m-1"  target="_blank" href="https://www.facebook.com/dielpartnersinternational" role="button"
      ><i class="fab fa-whatsapp"></i
      ></a>


      <!-- Twitter -->
      <a target="_blank" data-mdb-toggle="tooltip" title="Twitter" class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/DPIUSALLC" role="button"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a target="_blank"   data-mdb-toggle="tooltip" title="Youtube"class="btn btn-outline-light btn-floating m-1" href="https://www.youtube.com/channel/UCe5bcTViOxKYTvZQdoo7oZw" role="button"
        ><i class="fab fa-youtube"></i
      ></a>

      <!-- Instagram -->
      <a  target="_blank"  data-mdb-toggle="tooltip" title="Instagram" class="btn btn-outline-light btn-floating m-1" href="https://www.instagram.com/dpiusallc/" role="button"
        ><i class="fab fa-instagram"></i
      ></a>

      <!-- Linkedin -->
      <a target="_blank"   data-mdb-toggle="tooltip" title="Linkedin" class="btn btn-outline-light btn-floating m-1" href="https://www.linkedin.com/company/dpiusallc" role="button"
        ><i class="fab fa-linkedin-in"></i
      ></a>

    </section>
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    <a class="" target="_blank" href="<?php echo e(route('privacypolicy')); ?>">Privacy Policy |</a> 
    <a class="ms-2" target="_blank" href="<?php echo e(route('shippingpolicy')); ?>">Shipping Policy |</a> 
    <a class="ms-2" target="_blank" href="<?php echo e(route('returnpolicy')); ?>">Returns & Refunds Policy |</a>
    <a class="ms-2" target="_blank" href="<?php echo e(route('termspolicy')); ?>">Terms of Use</a>
  </div>
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2023 Copyright:
    <a class="text-white" href="#">DPI - Powered by DPI Digital</a>
  </div>
 
  <!-- Copyright -->
  
</footer><?php /**PATH C:\Users\HP\Documents\mesprojets\production\dpi_site\resources\views/partials/foot.blade.php ENDPATH**/ ?>