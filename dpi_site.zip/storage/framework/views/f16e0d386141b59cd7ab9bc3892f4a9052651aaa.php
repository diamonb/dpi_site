
<?php $__env->startSection("content"); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-10">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
        <?php echo e(session('status')); ?>

        <?php endif; ?>
        </div>
        <div class="text-center mb-3">
            <h5>Enter the code sent to your email address to validate your registration<span class="badge badge-secondary"><?php echo e(session('email')); ?></span></h5>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-4">
        <form>


            <!-- Email input -->
            <div class="form-outline mb-4">
                <input type="number" id="code" name="code" class="form-control" />
                <label class="form-label" for="code">Code</label>
            </div>

            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block mb-4">Submit</button>

        </form>
        </div>
    
    
        </div>
</div>
</div>

  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/register/mail_confirm.blade.php ENDPATH**/ ?>