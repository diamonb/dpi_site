
<?php $__env->startSection("content"); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-10">
        <?php if(session('status')): ?>
        <div class="alert alert-success">
        <?php echo e(session('status')); ?>

        <?php endif; ?>
        </div>
        <div class="text-center mb-3">
            <h5>Welcome back !</h5>
            <p>please click next to configure your accompt!</p>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-4">
        <form name="register" id="register" method="post" action="<?php echo e(route('resgister_start_configuration')); ?>">
         <?php echo csrf_field(); ?> 
            <button type="submit" class="btn btn-primary">Next</button>
        </form>
        </div>
    
    
        </div>
</div>
</div>

  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/register/mail_confirmation.blade.php ENDPATH**/ ?>