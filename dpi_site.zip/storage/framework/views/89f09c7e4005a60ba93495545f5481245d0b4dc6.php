
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Privacy Policy  </p>
    
  </div>

  <div class="container mt-5">
    <?php echo $page->description; ?>

  </div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/pages/privacy_policy.blade.php ENDPATH**/ ?>