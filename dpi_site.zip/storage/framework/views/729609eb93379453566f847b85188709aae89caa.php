
<?php $__env->startSection("content"); ?>


    <div class="row">
        <div class="col-md-3 side_1">

        </div>

        <div class="col-md-6 ">
            
        <div class="col text-center">
            <span class="h2 text-center">Finish Configuration</span>
        </div>
            
            <form class="mt-5" name="register" id="register" method="post" action="<?php echo e(route('activate_dashboard')); ?>">
                <?php echo csrf_field(); ?>
                    <div class="form-outline mb-4">
                        <label class="form-label" for="domain">Category*</label>
                        <select class="form-select" id="domain" aria-label="Default select example">
                        <option selected>Open this select category</option>
                        <option value="">Client</option> 
                        <option value="">Business (Do business with us)</option>
                        <option value="">Consultant (Become a Consultant)</option>
                        <option value="">Investor (Invest with us)</option>
                        <option value="">Partener (Partner with us)</option>
                        </select>
                        
                    </div>

                    <div class="form-outline mb-4">
                        <label class="form-label" for="domain">Country</label>
                        <select class="form-select" id="domain" aria-label="Default select example">
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    </div>

                    <div class="form-outline mb-4">
                        <label class="form-label" for="form6Example2">State</label>
                        <input type="text" id="form6Example2" class="form-outline" />
                        
                    </div>
                    
                    <div class="form-outline mb-4">
                        <label class="form-label" for="form6Example1">City</label>
                        <input type="text" id="form6Example1" class="form-outline" />
                        
                    </div>

                    <div class="form-outline mb-4">
                        <label class="form-label" for="form6Example2">Address</label>
                        <input type="text" id="form6Example2" class="form-outline" />
                        
                    </div>
                    <div class="form-outline mb-4">
                        <label class="form-label" for="form6Example6">Phone</label>
                        <input type="number" id="form6Example6" class="form-outline" />
                    </div>

                    
                    <div class="form-outline mb-4">
                        <label class="form-label" for="domain">Primary need*</label>
                        <select class="form-select" id="domain" aria-label="Default select example">
                        <option selected>Open this to select domain</option>
                        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($domain->id_domain); ?>"><?php echo e($domain->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                    </div>
                    <!-- Message input -->
                    <div class="form-outline mb-4">
                        <label class="form-label" for="form6Example7">Tell us about your project</label>
                        <textarea class="form-outline" id="form6Example7" rows="4"></textarea>    
                    </div>

                    <div class=" mb-4">
                        <label class="" for="customFile">Tell us about your project - Add file</label> 
                        <input type="file" class="form-control" id="customFile" />                   
                    </div>
                    <div class="form-outline mb-4">
                        <label class="form-label" for="website">Website</label>
                        <input type="text" id="website" class="form-outline" />
                    </div>


                <!-- Submit button -->
                <button type="submit" class="btn btn-primary btn-block mb-4">SUBMIT</button>
                </form>
        </div>

        <div class="col-md-3 side_1">

        </div>


    </div>
    

  <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/register/register_strat_configuration.blade.php ENDPATH**/ ?>