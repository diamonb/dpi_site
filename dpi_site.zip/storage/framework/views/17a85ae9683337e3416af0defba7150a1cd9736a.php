
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Returns & Refunds Policy</p>
    
  </div>
<div class="container">
    <span class="h3">Returns & Refunds Policy</span>
    <p>
    DPI services/products can be returned within 30 days of receipt of the product. To receive free shipping label, email your order number, and reason for return to dpi@dielpi.com. 
    If you have any questions, please call 713-292-4421during business hours (8am -5pm, CST). Upon receiving the returned product in good condition,
    full refund of the purchase price will be initiated to the same payment method used for purchase. Products returned in unsellable condition may be subject to partial refund.

            </p>
</div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/pages/return.blade.php ENDPATH**/ ?>