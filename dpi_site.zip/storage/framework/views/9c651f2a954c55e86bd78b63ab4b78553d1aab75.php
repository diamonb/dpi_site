
<?php $__env->startSection("content"); ?>
  <div class="banniere_shop">
    <p class="h1 text-center pt-5">Terms of Use</p>
    
  </div>
<div class="container mt-5">
    <p class="h4 mb-2 mt-5">Terms and Conditions</p>
    <?php echo $page->description; ?>

</div>

<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/pages/terms.blade.php ENDPATH**/ ?>