
<?php $__env->startSection("content"); ?>
  <div class="banniere_contact">
        <p class="h1 text-center pt-5">Contact us</p>
  </div>

  <div class="container">
    <div class="row">
        <div class="col-lg-10">
            <!--Section: Contact v.2-->
<section class="mb-4 mt-4">

<!--Section description-->
<p class="text-center w-responsive mx-auto mb-5">Feel free to contact our committed team to assist with your need now.</p>

<div class="row justify_context_center">

    <!--Grid column-->
    <div class="col-md-2">

    </div>

    <div class="col-md-8 mb-md-0 mb-5">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('succes')): ?>

        <div class="alert alert-success ">

            <button type="button" class="close" data-dismiss="alert">×</button>

            <strong><?php echo e($message); ?></strong>

        </div>

        <?php endif; ?>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <form id="contact-form" name="contact-form" action="<?php echo e(route('savecontact')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

            <!--Grid row-->
            <div class="row">

                <!--Grid column-->
                <div class="col-md-6">
                    <div class="md-form mb-0">
                        <label for="name" class="">Full name</label>
                        <input type="text" id="name" name="full_name" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['required'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6">
                    <div class="md-form mb-0">
                        <label for="email" class="">Email</label>
                        <input type="text" id="email" name="email" class="form-control">
                        
                    </div>
                </div>
                <!--Grid column-->

            </div>
            <!--Grid row-->

            <!--Grid row-->
            <div class="row">
                <div class="col-md-12">
                    <div class="md-form mb-0">
                        <label for="subject" class="">Subject</label>
                        <input type="text" id="subject" name="subject" class="form-control">
                    </div>
                </div>
            </div>
            <!--Grid row-->

            <!--Grid row-->
            <div class="row">

                <!--Grid column-->
                <div class="col-md-12">

                    <div class="md-form">
                    <label for="message">Message</label>
                        <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                        
                    </div>

                </div>
            </div>
            <!--Grid row-->

        </form>
        <br>
        <div class="text-center text-md-left">
            <a class="btn btn-primary" onclick="document.getElementById('contact-form').submit();">Send</a>
        </div>
        <div class="status"></div>
    </div>
    <div class="col-md-2">

</div>
    <!--Grid column-->
</div>
<div class="row mt-5">
            <div class="col-md-2">

            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col">
                    <i class="fas fa-map-marker-alt fa-2x text-warning"></i> <br>
                        <span> Houston,Texas (US)</span><br>
                        <span>Libreville, Gabon</span>
                    </div>

                    <div class="col text-center">
                        <i class="fas fa-phone fa-2x text-warning"></i> <br>
                            <span>+1 713-292-4421</span>
                    </div>

                    <div class="col text-end">
                        <p class="text-end"><i class="fas fa-envelope fa-2x text-end text-warning"></i></p>
                        
                            <span>dpi@dielpi.com </span> <br>
                            <span>commercial@dielpi.com </span><br>
                            <span>investors@dielpi.com</span>
                    </div>
                </div>
            </div>
            <div class="col-md-2">

            </div>
            

</div>

</section>
<!--Section: Contact v.2-->
        </div>
        <div class="col-lg-2">

        </div>
    </div>
 
  </div>


<footer>
    <?php echo $__env->make('partials/foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.masterother", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\mesprojets\DPI\site\dpi_site\resources\views/pages/contact.blade.php ENDPATH**/ ?>