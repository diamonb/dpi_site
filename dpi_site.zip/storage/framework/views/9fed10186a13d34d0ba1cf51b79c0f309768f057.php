
<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-lg-12">
            <h2 class="m-lg-4">Contacts</i></h2>

        </div>

    </div>
    <div class="row">
        <div class="col-md-6">
        <form action="<?php echo e(route('subscibe_newsletter')); ?>" method="POST">
        <!--Grid row-->
        
          <?php echo e(csrf_field()); ?>

            <button type="submit" class="btn btn-outline-success">
              Subscribe
            </button>
      </form>
        </div>
    
    </div>
    <div class="row">
            <table class="table">
            <thead class="thead-dark">
                <tr>
                <th scope="col">N°</th>
                <th scope="col">Email</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $newsletters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsletter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($newsletter->id_newsletter); ?></td>
                    <td><?php echo e($newsletter->email); ?></td>
                    <td><button class="btn btn-warning">Contact</button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("template.dashboard", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\disque_d_recup\mesprojets\DPI\site\dpi_site\resources\views/user/list_newsletter.blade.php ENDPATH**/ ?>